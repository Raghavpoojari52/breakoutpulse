# BreakoutPulse NSE: Android / Play Store guide

App id: `com.breakoutpulse.nse` (change in `capacitor.config.ts` AND `android/app/build.gradle` BEFORE first Play upload; it can never change afterwards).

## A. Build in the cloud (no Android Studio needed)
1. Create a GitHub repo and push this folder (`git init && git add . && git commit -m init && git push`).
2. GitHub > Actions > "Build Android (APK + AAB)" > Run workflow.
3. Download the `android-builds` artifact. `app-debug.apk` installs on your phone for testing (allow "install unknown apps").

## B. Create your signing key (once, keep it safe, never lose it)
```
keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias breakoutpulse
base64 -w0 release.jks     # macOS: base64 -i release.jks
```
Add GitHub repo secrets: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (breakoutpulse), `KEY_PASSWORD`.
Re-run the workflow; it now also produces a signed `app-release.aab`.

## C. Publish on Google Play
1. Register at play.google.com/console (one-time US$25, ID verification).
2. Create app > upload the `.aab` (Play App Signing: accept).
3. Listing: icon `assets/playstore-icon-512.png`, feature graphic 1024x500, 2-8 phone screenshots (take them from your phone), short + full description.
4. Fill: Privacy policy URL, Data safety, Content rating, Target audience (18+), App category Finance.
5. Finance declaration: state clearly that prices/signals are SIMULATED / educational, not investment advice, and the app does not execute real trades.
6. New personal accounts: run a closed test with 12+ testers for 14 days, then apply for production.

## Local build alternative
`npm install && npm run build && npx cap sync android && npx cap open android` > Build > Generate Signed Bundle.
After any code change: `npm run build && npx cap sync android`.

---
# Live market data (Upstox) setup: do this BEFORE building the release

How it works: each user taps **Connect Upstox**, logs in with their OWN free Upstox account, and the app fetches NSE prices/daily candles with that user's token. Your developer token is never shared. Users without Upstox still see the clearly-labelled **Demo** data.

1. Open a free Upstox account, then create an app at https://account.upstox.com/developer/apps.
   Redirect URL = `https://<your-server>/auth/callback`. Note the API key (client id) and secret.
2. Deploy `server/` (Render / Railway / Cloud Run, Node 20+, `npm start`). Env vars: `UPSTOX_CLIENT_ID`, `UPSTOX_CLIENT_SECRET`, `UPSTOX_REDIRECT_URI`. Check `https://<your-server>/health`.
3. GitHub repo > Settings > Variables > add `VITE_BACKEND_URL` = `https://<your-server>`. (Local: put it in `.env.production`.)
4. Rebuild (workflow). Install the debug APK, tap **Connect Upstox**, log in. Header should change from DEMO to UPSTOX.
5. Play Console > Data safety: declare that the app handles an authentication token (on-device only, not shared) and uses the Upstox login. Keep the privacy policy URL.
6. Upstox may ask about apps built on its API: email api@upstox.com describing the app (read-only quotes/candles, per-user login) to be safe.

Notes: RVOL = today's volume so far / 20-day average, so it reads low early in the session. "Delivery %" is NOT available from Upstox and still shows demo values. Backtest tab is still illustrative.
