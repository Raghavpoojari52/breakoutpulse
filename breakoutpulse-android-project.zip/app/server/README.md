# BreakoutPulse auth server
1. Create an app at https://account.upstox.com/developer/apps (free). Set **Redirect URL** to `https://<your-host>/auth/callback`.
2. Deploy this folder to Render / Railway / Cloud Run (Node 20+, start: `npm start`). Env vars:
   `UPSTOX_CLIENT_ID`, `UPSTOX_CLIENT_SECRET`, `UPSTOX_REDIRECT_URI`, optional `APP_SCHEME` (default `com.breakoutpulse.nse`).
3. Put the server URL in the app's `.env` as `VITE_BACKEND_URL=https://<your-host>` and rebuild.
Keep a single instance (tickets live in memory for 60 s).
