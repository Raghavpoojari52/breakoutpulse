// BreakoutPulse NSE – tiny auth + instrument-lookup server.
// Keeps the Upstox client_secret OFF the phone. It never stores or logs market data or tokens
// beyond a 60-second, single-use hand-off ticket held in memory.
import express from 'express';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { promisify } from 'node:util';

const gunzip = promisify(zlib.gunzip);
const {
  UPSTOX_CLIENT_ID, UPSTOX_CLIENT_SECRET,
  UPSTOX_REDIRECT_URI,                       // e.g. https://your-server.onrender.com/auth/callback
  APP_SCHEME = 'com.breakoutpulse.nse',      // must match the Android intent-filter
  PORT = 8080,
} = process.env;

for (const k of ['UPSTOX_CLIENT_ID', 'UPSTOX_CLIENT_SECRET', 'UPSTOX_REDIRECT_URI']) {
  if (!process.env[k]) console.warn(`[warn] ${k} is not set`);
}

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '4kb' }));

const states = new Map();   // state -> expiresAt
const tickets = new Map();  // ticket -> { token, exp }
const TTL = 60_000;
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of states) if (v < now) states.delete(k);
  for (const [k, v] of tickets) if (v.exp < now) tickets.delete(k);
}, 30_000).unref();

app.get('/health', (_req, res) => res.json({ ok: true }));

// 1) App opens this in a browser tab -> we forward to Upstox login.
app.get('/auth/start', (_req, res) => {
  const state = crypto.randomBytes(16).toString('hex');
  states.set(state, Date.now() + 10 * 60_000);
  const url = new URL('https://api.upstox.com/v2/login/authorization/dialog');
  url.search = new URLSearchParams({
    client_id: UPSTOX_CLIENT_ID ?? '', redirect_uri: UPSTOX_REDIRECT_URI ?? '',
    response_type: 'code', state,
  }).toString();
  res.redirect(url.toString());
});

// 2) Upstox sends the user back here with ?code. We swap it for a token and hand the app a one-time ticket.
app.get('/auth/callback', async (req, res) => {
  const { code, state } = req.query;
  if (!code || !state || !states.has(state)) return res.status(400).send('Invalid or expired login. Please try again from the app.');
  states.delete(state);
  try {
    const r = await fetch('https://api.upstox.com/v2/login/authorization/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
      body: new URLSearchParams({
        code: String(code), client_id: UPSTOX_CLIENT_ID, client_secret: UPSTOX_CLIENT_SECRET,
        redirect_uri: UPSTOX_REDIRECT_URI, grant_type: 'authorization_code',
      }),
    });
    const j = await r.json();
    if (!r.ok || !j.access_token) throw new Error('token exchange failed');
    const ticket = crypto.randomBytes(24).toString('hex');
    tickets.set(ticket, { token: j.access_token, exp: Date.now() + TTL });
    const deep = `${APP_SCHEME}://auth?ticket=${ticket}`;
    res.type('html').send(`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">
<body style="font-family:sans-serif;background:#020617;color:#e2e8f0;text-align:center;padding:48px 20px">
<h2>Login successful</h2><p>Returning to BreakoutPulse…</p>
<p><a style="color:#34d399" href="${deep}">Tap here if the app does not open</a></p>
<script>location.href=${JSON.stringify(deep)}</script></body>`);
  } catch {
    res.status(502).send('Could not complete Upstox login. Please try again.');
  }
});

// 3) App redeems the ticket (single use, 60 s) for the access token.
app.post('/auth/redeem', (req, res) => {
  const t = tickets.get(req.body?.ticket);
  if (!t || t.exp < Date.now()) return res.status(404).json({ error: 'invalid_ticket' });
  tickets.delete(req.body.ticket);
  res.set('Cache-Control', 'no-store').json({ access_token: t.token });
});

// 4) Symbol -> Upstox instrument_key (public master file, cached 12 h). No user data involved.
let master = { at: 0, map: new Map() };
async function loadMaster() {
  if (Date.now() - master.at < 12 * 3600_000 && master.map.size) return master.map;
  const r = await fetch('https://assets.upstox.com/market-quote/instruments/exchange/NSE.json.gz');
  if (!r.ok) throw new Error('master fetch failed');
  const rows = JSON.parse((await gunzip(Buffer.from(await r.arrayBuffer()))).toString('utf8'));
  const map = new Map();
  for (const x of rows) {
    if (x.segment === 'NSE_EQ' && x.instrument_type === 'EQ') map.set(x.trading_symbol, x.instrument_key);
  }
  master = { at: Date.now(), map };
  return map;
}
app.get('/instruments', async (req, res) => {
  try {
    const want = String(req.query.symbols ?? '').split(',').map((s) => s.trim().toUpperCase()).filter(Boolean).slice(0, 200);
    const map = await loadMaster();
    const out = {};
    for (const s of want) if (map.has(s)) out[s] = map.get(s);
    res.set('Cache-Control', 'public, max-age=3600').json(out);
  } catch {
    res.status(502).json({ error: 'instrument_master_unavailable' });
  }
});

app.listen(PORT, () => console.log(`auth server on :${PORT}`));
