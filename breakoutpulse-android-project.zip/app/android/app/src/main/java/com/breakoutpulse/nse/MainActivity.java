package com.breakoutpulse.nse;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
