import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.breakoutpulse.nse',
  appName: 'BreakoutPulse NSE',
  webDir: 'dist',
  backgroundColor: '#020617',
  android: { allowMixedContent: false },
  plugins: {
    CapacitorHttp: { enabled: true },
    SplashScreen: { launchShowDuration: 1200, backgroundColor: '#020617', showSpinner: false },
    StatusBar: { style: 'DARK', backgroundColor: '#020617' },
  },
};

export default config;
