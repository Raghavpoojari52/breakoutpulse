import { App as CapApp } from '@capacitor/app';
import { Browser } from '@capacitor/browser';
import type { StockBreakout } from '../types/trading';
import { buildSetup, withDmas } from '../utils/liveSetup';

export const BACKEND = (import.meta.env.VITE_BACKEND_URL as string | undefined)?.replace(/\/$/, '') ?? '';
const API = 'https://api.upstox.com/v2';
const TOKEN_KEY = 'bp_upstox_token';

export interface IndexTick { label: string; value: number; pct: number }
export const INDEX_KEYS: Record<string, string> = {
  NIFTY: 'NSE_INDEX|Nifty 50',
  SENSEX: 'BSE_INDEX|SENSEX',
  BANKNIFTY: 'NSE_INDEX|Nifty Bank',
  'INDIA VIX': 'NSE_INDEX|India VIX',
};

export const getToken = () => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } };
export const setToken = (t: string | null) => { try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ } };
export const isBackendConfigured = () => BACKEND.length > 0;

/** Opens Upstox login in a browser tab; resolves via deep link handled by listenForLogin(). */
export async function startLogin() {
  if (!BACKEND) throw new Error('Backend URL not configured');
  await Browser.open({ url: `${BACKEND}/auth/start` });
}

/** Call once on app start. Handles com.breakoutpulse.nse://auth?ticket=... */
export function listenForLogin(onToken: (t: string) => void, onError: (m: string) => void) {
  const sub = CapApp.addListener('appUrlOpen', async ({ url }) => {
    try {
      const u = new URL(url);
      const ticket = u.searchParams.get('ticket');
      if (!ticket) return;
      await Browser.close().catch(() => {});
      const r = await fetch(`${BACKEND}/auth/redeem`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ticket }),
      });
      if (!r.ok) throw new Error('Login expired. Please try again.');
      const { access_token } = await r.json();
      setToken(access_token);
      onToken(access_token);
    } catch (e) { onError(e instanceof Error ? e.message : 'Login failed'); }
  });
  return () => { sub.then((s) => s.remove()); };
}

export class UpstoxAuthError extends Error {}

async function get(path: string, token: string) {
  const r = await fetch(`${API}${path}`, { headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' } });
  if (r.status === 401) throw new UpstoxAuthError('Session expired');
  if (!r.ok) throw new Error(`Upstox ${r.status}`);
  return r.json();
}

type QuoteMap = Record<string, { last: number; netChange: number; volume: number }>;
async function quotes(keys: string[], token: string): Promise<QuoteMap> {
  const j = await get(`/market-quote/quotes?instrument_key=${keys.map(encodeURIComponent).join(',')}`, token);
  const out: QuoteMap = {};
  for (const [k, v] of Object.entries<any>(j.data ?? {})) {
    const tok = (v.instrument_token as string) || k.replace(':', '|');
    out[tok] = { last: v.last_price, netChange: v.net_change ?? 0, volume: v.volume ?? 0 };
  }
  return out;
}

export async function fetchIndices(token: string): Promise<IndexTick[]> {
  const q = await quotes(Object.values(INDEX_KEYS), token);
  return Object.entries(INDEX_KEYS).flatMap(([label, key]) => {
    const x = q[key]; if (!x || !x.last) return [];
    const prev = x.last - x.netChange;
    return [{ label, value: x.last, pct: prev ? (x.netChange / prev) * 100 : 0 }];
  });
}

const istDate = (d = new Date()) => new Date(d.getTime() + 5.5 * 3600_000).toISOString().slice(0, 10);

async function dailyCandles(key: string, token: string) {
  const to = istDate(), from = istDate(new Date(Date.now() - 140 * 86400_000));
  const j = await get(`/historical-candle/${encodeURIComponent(key)}/day/${to}/${from}`, token);
  const today = istDate();
  const rows: any[][] = (j.data?.candles ?? []).filter((c: any[]) => String(c[0]).slice(0, 10) < today);
  return withDmas(rows.reverse().map((c) => ({
    date: new Date(String(c[0]).slice(0, 10)).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
    open: c[1], high: c[2], low: c[3], close: c[4], volume: c[5],
  })));
}

/** Mutates the given stock objects in place with real data. Returns how many were updated. */
export async function refreshStocks(stocks: StockBreakout[], token: string): Promise<number> {
  const res = await fetch(`${BACKEND}/instruments?symbols=${stocks.map((s) => s.symbol).join(',')}`);
  const keys: Record<string, string> = res.ok ? await res.json() : {};
  const q = await quotes(Object.values(keys), token);
  let n = 0;
  await Promise.all(stocks.map(async (s) => {
    const key = keys[s.symbol]; if (!key || !q[key]) return;
    const candles = await dailyCandles(key, token);
    const patch = buildSetup(candles, q[key]);
    if (patch) { Object.assign(s, patch); n++; }
  }));
  return n;
}
