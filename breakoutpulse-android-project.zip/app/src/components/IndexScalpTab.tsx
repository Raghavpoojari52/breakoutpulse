import React, { useState } from 'react';
import {
  Activity,
  Zap,
  ArrowUp,
  ArrowDown,
  Clock,
  ShieldCheck,
  TrendingUp,
  SlidersHorizontal,
} from 'lucide-react';
import { formatINR } from '../utils/calculations';

export const IndexScalpTab: React.FC = () => {
  const [selectedIndex, setSelectedIndex] = useState<'NIFTY' | 'BANKNIFTY'>('NIFTY');

  const niftyData = {
    spot: 24850.20,
    change: +145.8,
    changePct: +0.59,
    pcr: 1.18,
    maxPain: 24800,
    cprTop: 24865,
    cprPivot: 24820,
    cprBottom: 24775,
    r1: 24920,
    s1: 24740,
    bias: 'BULLISH SQUEEZE',
    signal: 'BUY CALL (24850 CE) above 24865 on 3-min close',
  };

  const bankNiftyData = {
    spot: 52140.80,
    change: +320.4,
    changePct: +0.62,
    pcr: 1.05,
    maxPain: 52000,
    cprTop: 52190,
    cprPivot: 52080,
    cprBottom: 51970,
    r1: 52350,
    s1: 51850,
    bias: 'RANGE EXPANSION',
    signal: 'LONG SCALP: Target 52,300 with 40-pt SL',
  };

  const data = selectedIndex === 'NIFTY' ? niftyData : bankNiftyData;

  return (
    <div className="space-y-5 pb-16">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white">Index Scalping & CPR Levels</h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
              1-Min / 5-Min Scalp
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional Central Pivot Range (CPR), Put-Call Ratio (PCR), and option chain flow triggers.
          </p>
        </div>

        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setSelectedIndex('NIFTY')}
            className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
              selectedIndex === 'NIFTY'
                ? 'bg-emerald-500 text-slate-950 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            NIFTY 50
          </button>
          <button
            onClick={() => setSelectedIndex('BANKNIFTY')}
            className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
              selectedIndex === 'BANKNIFTY'
                ? 'bg-emerald-500 text-slate-950 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            BANKNIFTY
          </button>
        </div>
      </div>

      {/* Main Spot Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{selectedIndex} Spot Index</span>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-white mt-0.5">
              {data.spot.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
              +{data.change.toFixed(2)} (+{data.changePct}%)
            </span>
            <span className="text-[11px] text-slate-400 block mt-1 font-mono">Bias: {data.bias}</span>
          </div>
        </div>

        {/* CPR & Options Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase block font-sans">Put-Call Ratio (PCR)</span>
            <span className="text-base font-bold text-emerald-400">{data.pcr}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Bullish Support</span>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase block font-sans">Option Max Pain</span>
            <span className="text-base font-bold text-white">{data.maxPain}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Expiry Anchor</span>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase block font-sans">CPR Width</span>
            <span className="text-base font-bold text-cyan-400">Narrow (Trending)</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">High probability trend</span>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase block font-sans">Pivot Central</span>
            <span className="text-base font-bold text-amber-400">{data.cprPivot}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Top: {data.cprTop} | Bot: {data.cprBottom}</span>
          </div>
        </div>

        {/* Scalp Signal Alert Box */}
        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0">
            <Zap className="w-4 h-4 fill-current" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 block">
              Active Scalping Action Plan
            </span>
            <p className="text-xs font-semibold text-white mt-0.5">{data.signal}</p>
            <p className="text-[11px] text-slate-300 mt-1">
              R1 Resistance at {data.r1} • S1 Demand Floor at {data.s1}.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
