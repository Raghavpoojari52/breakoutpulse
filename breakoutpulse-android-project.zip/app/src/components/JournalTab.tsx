import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  CheckCircle2,
  XCircle,
  Tag,
  Calendar,
  Camera,
  Star,
  Search,
} from 'lucide-react';
import { JournalEntry } from '../types/trading';
import { formatINR } from '../utils/calculations';

export const JournalTab: React.FC = () => {
  const [entries, setEntries] = useState<JournalEntry[]>([
    {
      id: '1',
      date: '24 Oct 2024',
      symbol: 'DIXON',
      outcome: 'WIN',
      pnl: 188000,
      setupType: 'Volume Breakout RVOL > 2.0x',
      disciplineScore: 10,
      notes: 'Waited patiently for 15M candle to close above ₹15,450. RVOL was 2.39x. Did not front-run entry. Hit Target 1 cleanly in 18 days.',
      rulesFollowed: true,
      tags: ['Discipline', '15M Close Rule', 'Earnings Momentum'],
    },
    {
      id: '2',
      date: '19 Oct 2024',
      symbol: 'LT',
      outcome: 'WIN',
      pnl: 116000,
      setupType: 'Complete Swing Breakout',
      disciplineScore: 9,
      notes: 'Clean 20/50 DMA bullish stack. Kept trailing stop at 20 DMA as stock trended. Sized within 1% capital risk limit.',
      rulesFollowed: true,
      tags: ['Capex Cycle', 'Trailing SL', 'LargeCap'],
    },
    {
      id: '3',
      date: '12 Oct 2024',
      symbol: 'TATAELXSI',
      outcome: 'LOSS',
      pnl: -35100,
      setupType: 'Breakout Failure Retest',
      disciplineScore: 8,
      notes: 'Cut immediately on daily candle closing below 50 DMA support. Followed predetermined stop loss without hoping.',
      rulesFollowed: true,
      tags: ['Stop Loss Respected', 'No Regret'],
    },
  ]);

  const [filterOutcome, setFilterOutcome] = useState<'ALL' | 'WIN' | 'LOSS'>('ALL');
  const [newNote, setNewNote] = useState('');
  const [newSymbol, setNewSymbol] = useState('BHARTIARTL');

  const filtered = entries.filter((e) => {
    if (filterOutcome !== 'ALL' && e.outcome !== filterOutcome) return false;
    return true;
  });

  return (
    <div className="space-y-5 pb-16">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-white">Trade Journal & Screenshot Logs</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Log trade psychology, emotional discipline, and execution adherence to rules.
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          {(['ALL', 'WIN', 'LOSS'] as const).map((o) => (
            <button
              key={o}
              onClick={() => setFilterOutcome(o)}
              className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                filterOutcome === o
                  ? 'bg-emerald-500 text-slate-950'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {o}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white text-sm font-mono">{item.symbol}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    item.outcome === 'WIN'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  {item.outcome}
                </span>
                <span className="text-slate-500 font-mono text-[11px]">{item.date}</span>
              </div>

              <span
                className={`font-mono font-bold ${
                  item.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {item.pnl >= 0 ? '+' : ''}{formatINR(item.pnl)}
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-300">
              <span className="font-semibold text-emerald-400">Setup:</span>
              <span>{item.setupType}</span>
              <span className="ml-auto text-[11px] text-amber-400 flex items-center gap-1 font-mono">
                <Star className="w-3 h-3 fill-current" />
                <span>Discipline: {item.disciplineScore}/10</span>
              </span>
            </div>

            <p className="text-xs text-slate-300 bg-slate-950/50 p-3 rounded-xl border border-slate-800/60 leading-relaxed">
              "{item.notes}"
            </p>

            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              {item.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 font-medium"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
