import React, { useState } from 'react';
import {
  Wallet,
  ArrowUpRight,
  Plus,
  RotateCcw,
  ShieldCheck,
  Building2,
  CheckCircle2,
  TrendingUp,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { Position, Order } from '../types/trading';
import { formatINR, calculatePnL } from '../utils/calculations';
import { MOCK_STOCKS } from '../data/mockStocks';

interface TradeTerminalTabProps {
  positions: Position[];
  orders: Order[];
  onPlaceOrder: (order: Omit<Order, 'id' | 'placedAt'>) => void;
  onClosePosition: (id: string) => void;
  onResetAccount: () => void;
}

export const TradeTerminalTab: React.FC<TradeTerminalTabProps> = ({
  positions,
  orders,
  onPlaceOrder,
  onClosePosition,
  onResetAccount,
}) => {
  const [tradingMode, setTradingMode] = useState<'paper' | 'real'>('paper');
  const [activeSubtab, setActiveSubtab] = useState<'positions' | 'order' | 'orderbook' | 'broker'>('positions');

  // Order Form State
  const [orderSymbol, setOrderSymbol] = useState(MOCK_STOCKS[0].symbol);
  const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT' | 'GTT_BREAKOUT'>('MARKET');
  const [orderQty, setOrderQty] = useState(10);
  const [orderPrice, setOrderPrice] = useState(MOCK_STOCKS[0].currentPrice);
  const [orderSl, setOrderSl] = useState(MOCK_STOCKS[0].stopLoss);
  const [orderTarget, setOrderTarget] = useState(MOCK_STOCKS[0].target1);

  const selectedStock = MOCK_STOCKS.find((s) => s.symbol === orderSymbol) || MOCK_STOCKS[0];

  // Capital calculations
  const initialCapital = 1000000;
  const investedValue = positions.reduce((acc, p) => acc + p.quantity * p.avgPrice, 0);
  const unrealizedPnL = positions.reduce((acc, p) => acc + p.pnl, 0);
  const totalPortfolioValue = initialCapital + unrealizedPnL;
  const availableMargin = initialCapital - investedValue;

  const handleStockChange = (sym: string) => {
    setOrderSymbol(sym);
    const stock = MOCK_STOCKS.find((s) => s.symbol === sym);
    if (stock) {
      setOrderPrice(stock.currentPrice);
      setOrderSl(stock.stopLoss);
      setOrderTarget(stock.target1);
    }
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    onPlaceOrder({
      symbol: orderSymbol,
      type: 'BUY',
      orderType,
      quantity: Number(orderQty),
      price: Number(orderPrice),
      status: 'EXECUTED',
    });
    setActiveSubtab('positions');
  };

  return (
    <div className="space-y-5 pb-16">
      {/* Mode Switcher: Paper Trading vs Real Broker Live */}
      <div className="flex bg-slate-900 border border-slate-800 rounded-2xl p-1 shadow-lg">
        <button
          onClick={() => setTradingMode('paper')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
            tradingMode === 'paper'
              ? 'bg-emerald-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-slate-950 animate-pulse" />
          <span>Paper Trading (₹10L)</span>
        </button>

        <button
          onClick={() => setTradingMode('real')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
            tradingMode === 'real'
              ? 'bg-emerald-500 text-slate-950 shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Real Broker Live</span>
        </button>
      </div>

      {/* Demat Account Overview Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
            <Wallet className="w-4 h-4 text-emerald-400" />
            <span>NSE VIRTUAL DEMAT ACCOUNT</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onResetAccount}
              className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 transition cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
              INR
            </span>
          </div>
        </div>

        {/* Portfolio Value Display */}
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <div>
            <span className="text-[10px] uppercase font-semibold text-slate-500">Total Portfolio Value</span>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-white">
              {formatINR(totalPortfolioValue)}
            </div>
          </div>
          <div className="text-right">
            <span className="text-[10px] uppercase font-semibold text-slate-500">Total P&L</span>
            <div className={`text-base font-mono font-bold ${unrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {unrealizedPnL >= 0 ? '↗ ' : '↘ '}
              {formatINR(unrealizedPnL)}
            </div>
          </div>
        </div>

        {/* 3 Margin Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl font-mono">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block">Available Margin</span>
            <span className="text-sm font-bold text-white">{formatINR(availableMargin)}</span>
          </div>
          <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl font-mono">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block">Invested Value</span>
            <span className="text-sm font-bold text-slate-300">{formatINR(investedValue)}</span>
          </div>
          <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl font-mono">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block">Unrealized P&L</span>
            <span className={`text-sm font-bold ${unrealizedPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {formatINR(unrealizedPnL)}
            </span>
          </div>
        </div>
      </div>

      {/* Subtabs Navigation */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="flex border-b border-slate-800 bg-slate-950/60 p-1">
          <button
            onClick={() => setActiveSubtab('positions')}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
              activeSubtab === 'positions'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Positions ({positions.length})
          </button>
          <button
            onClick={() => setActiveSubtab('order')}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
              activeSubtab === 'order'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Place Order
          </button>
          <button
            onClick={() => setActiveSubtab('orderbook')}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
              activeSubtab === 'orderbook'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Order Book ({orders.length})
          </button>
          <button
            onClick={() => setActiveSubtab('broker')}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
              activeSubtab === 'broker'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Broker Bridge
          </button>
        </div>

        {/* Subtab Content: Positions */}
        {activeSubtab === 'positions' && (
          <div className="p-5">
            {positions.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto text-slate-400">
                  <Wallet className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">No Open Positions</h4>
                  <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                    Place a paper trade or live order from the Place Order tab or Breakout Scanner.
                  </p>
                </div>
                <button
                  onClick={() => setActiveSubtab('order')}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-xl transition shadow-lg shadow-emerald-500/20 cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Place New Order</span>
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-800 text-xs font-mono">
                {positions.map((pos) => (
                  <div key={pos.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{pos.symbol}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                          {pos.type} {pos.quantity} QTY
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Avg: {formatINR(pos.avgPrice)} • CMP: {formatINR(pos.currentPrice)}
                      </p>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-4">
                      <div className="text-right">
                        <span className={`font-bold ${pos.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {pos.pnl >= 0 ? '+' : ''}{formatINR(pos.pnl)}
                        </span>
                        <span className="text-[11px] text-slate-400 block">
                          ({pos.pnlPercent >= 0 ? '+' : ''}{pos.pnlPercent}%)
                        </span>
                      </div>

                      <button
                        onClick={() => onClosePosition(pos.id)}
                        className="px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[11px] font-bold transition cursor-pointer"
                      >
                        Square Off
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Subtab Content: Place Order Form */}
        {activeSubtab === 'order' && (
          <form onSubmit={handleSubmitOrder} className="p-5 space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                  NSE Symbol
                </label>
                <select
                  value={orderSymbol}
                  onChange={(e) => handleStockChange(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  {MOCK_STOCKS.map((s) => (
                    <option key={s.symbol} value={s.symbol}>
                      {s.symbol} - {s.name} ({formatINR(s.currentPrice)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                  Order Type
                </label>
                <select
                  value={orderType}
                  onChange={(e) => setOrderType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="MARKET">Market Order</option>
                  <option value="LIMIT">Limit Order</option>
                  <option value="GTT_BREAKOUT">GTT Breakout Trigger</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                  Quantity
                </label>
                <input
                  type="number"
                  min="1"
                  value={orderQty}
                  onChange={(e) => setOrderQty(Math.max(1, Number(e.target.value)))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                  Execution Price
                </label>
                <input
                  type="number"
                  value={orderPrice}
                  onChange={(e) => setOrderPrice(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="bg-slate-950/70 border border-slate-800 p-3.5 rounded-xl space-y-2 font-mono">
              <div className="flex justify-between text-slate-400">
                <span>Calculated Margin Required:</span>
                <span className="font-bold text-white">{formatINR(orderQty * orderPrice)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Available Margin:</span>
                <span className="text-emerald-400 font-bold">{formatINR(availableMargin)}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={orderQty * orderPrice > availableMargin}
              className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-emerald-500/20 transition cursor-pointer"
            >
              Execute Buy Order
            </button>
          </form>
        )}

        {/* Subtab Content: Order Book */}
        {activeSubtab === 'orderbook' && (
          <div className="p-5">
            {orders.length === 0 ? (
              <p className="text-center text-xs text-slate-400 py-8">No orders placed yet today.</p>
            ) : (
              <div className="divide-y divide-slate-800 text-xs font-mono">
                {orders.map((ord) => (
                  <div key={ord.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white">{ord.symbol}</span>
                      <span className="text-[10px] ml-2 text-slate-400">
                        {ord.orderType} • {ord.quantity} QTY @ {formatINR(ord.price)}
                      </span>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                      {ord.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Subtab Content: Broker Bridge */}
        {activeSubtab === 'broker' && (
          <div className="p-5 space-y-4 text-xs">
            <div className="flex items-center gap-2 p-3 bg-slate-950/80 border border-slate-800 rounded-xl">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <div>
                <h5 className="font-semibold text-white">NSE Certified Broker Gateway</h5>
                <p className="text-[11px] text-slate-400">
                  Connect via API Key & Secret for automated GTT breakout execution with Zerodha Kite, Angel One, or Upstox.
                </p>
              </div>
            </div>

            <div className="space-y-3">
              {['Zerodha Kite Connect', 'Angel One SmartAPI', 'Groww API'].map((broker) => (
                <div key={broker} className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-white">{broker}</span>
                    <span className="block text-[11px] text-slate-500">OAuth 2.0 / TOTP 2FA Supported</span>
                  </div>
                  <button className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition cursor-pointer">
                    Connect
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
