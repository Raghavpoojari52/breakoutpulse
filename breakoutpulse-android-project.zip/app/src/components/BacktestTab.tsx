import React, { useState } from 'react';
import {
  TrendingUp,
  Percent,
  Award,
  AlertOctagon,
  Play,
  RotateCcw,
  CheckCircle2,
  FileSpreadsheet,
  Download,
  Sliders,
} from 'lucide-react';
import { formatINR } from '../utils/calculations';

interface BacktestTabProps {
  onDeployToPaper: () => void;
}

export const BacktestTab: React.FC<BacktestTabProps> = ({ onDeployToPaper }) => {
  const [selectedStrategy, setSelectedStrategy] = useState('complete-swing');
  const [activeSubtab, setActiveSubtab] = useState<'performance' | 'trades' | 'params'>('performance');

  const tradeLogs = [
    { id: '1', date: 'Oct 2024', symbol: 'DIXON', type: 'BUY', entry: '₹12,450', exit: '₹14,800', pnl: '+ ₹1,88,000', returnPct: '+18.8%', duration: '18 Days', outcome: 'WIN' },
    { id: '2', date: 'Sep 2024', symbol: 'BHARTIARTL', type: 'BUY', entry: '₹1,540', exit: '₹1,685', pnl: '+ ₹94,250', returnPct: '+9.4%', duration: '14 Days', outcome: 'WIN' },
    { id: '3', date: 'Sep 2024', symbol: 'LT', type: 'BUY', entry: '₹3,420', exit: '₹3,710', pnl: '+ ₹1,16,000', returnPct: '+8.4%', duration: '22 Days', outcome: 'WIN' },
    { id: '4', date: 'Aug 2024', symbol: 'TATAELXSI', type: 'BUY', entry: '₹7,150', exit: '₹6,880', pnl: '- ₹35,100', returnPct: '-3.7%', duration: '6 Days', outcome: 'LOSS' },
    { id: '5', date: 'Aug 2024', symbol: 'TRENT', type: 'BUY', entry: '₹5,200', exit: '₹6,150', pnl: '+ ₹1,90,000', returnPct: '+18.2%', duration: '26 Days', outcome: 'WIN' },
    { id: '6', date: 'Jul 2024', symbol: 'EMS', type: 'BUY', entry: '₹640', exit: '₹735', pnl: '+ ₹76,000', returnPct: '+14.8%', duration: '16 Days', outcome: 'WIN' },
    { id: '7', date: 'Jul 2024', symbol: 'RELIANCE', type: 'BUY', entry: '₹1,320', exit: '₹1,295', pnl: '- ₹22,589', returnPct: '-1.8%', duration: '8 Days', outcome: 'LOSS' },
  ];

  return (
    <div className="space-y-5 pb-16">
      {/* Strategy Selector Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">Complete Swing Breakout</h2>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                Historical Win Rate: 58% - 66%
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              20/50/200 DMA Bullish Stack + 1.5x RVOL Expansion + Pivot Resistance Close.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedStrategy}
              onChange={(e) => setSelectedStrategy(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="complete-swing">Complete Swing Breakout</option>
              <option value="vcp-minervini">Minervini VCP Contraction</option>
              <option value="retest-volume">High-Volume Retest</option>
              <option value="mtf-30-40">MTF 30-40 Days Base</option>
            </select>
          </div>
        </div>

        {/* 4 KPI Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
          <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Net Profit</span>
            <span className="text-lg font-mono font-bold text-emerald-400">+ ₹ 8,48,582.94</span>
            <span className="text-[11px] text-emerald-400/90 block font-mono font-medium">(+84.9%)</span>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Win Rate</span>
            <span className="text-lg font-mono font-bold text-white">68.6%</span>
            <span className="text-[11px] text-slate-400 block font-mono">24W / 11L</span>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Profit Factor</span>
            <span className="text-lg font-mono font-bold text-cyan-400">3.86x</span>
            <span className="text-[11px] text-slate-400 block font-mono">Sharpe: 3.8</span>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl">
            <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Max Drawdown</span>
            <span className="text-lg font-mono font-bold text-rose-400">-3.7%</span>
            <span className="text-[11px] text-slate-400 block font-mono">₹ 57,689</span>
          </div>
        </div>
      </div>

      {/* Equity Curve Graph Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <h3 className="font-semibold text-white">Simulation Equity Curve</h3>
          </div>
          <div className="font-mono text-[11px] space-x-3">
            <span className="text-slate-400">Initial: <span className="text-white">₹ 10,00,000</span></span>
            <span className="text-slate-400">End: <span className="text-emerald-400 font-bold">₹ 18,48,582.94</span></span>
          </div>
        </div>

        {/* SVG Equity Curve Chart */}
        <div className="relative w-full h-[180px] bg-slate-950/90 border border-slate-800/80 rounded-xl p-3 overflow-hidden">
          <svg viewBox="0 0 600 160" className="w-full h-full" preserveAspectRatio="none">
            <defs>
              <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Baseline */}
            <line x1="20" y1="130" x2="580" y2="130" stroke="#334155" strokeDasharray="3 3" strokeWidth="1" />

            {/* Fill Area */}
            <path
              d="M 20 130 Q 120 115, 200 85 T 380 65 T 500 30 L 560 25 L 560 130 Z"
              fill="url(#equityGrad)"
            />

            {/* Main Equity Path */}
            <path
              d="M 20 130 Q 120 115, 200 85 T 380 65 T 500 30 L 560 25"
              fill="none"
              stroke="#10b981"
              strokeWidth="2.5"
            />

            {/* End point dot */}
            <circle cx="560" cy="25" r="4" fill="#10b981" />
            <circle cx="20" cy="130" r="3.5" fill="#94a3b8" />
          </svg>

          <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono mt-1 px-2">
            <span>Month 0 (Start)</span>
            <span>Month 1</span>
            <span>Month 2</span>
            <span>Month 3</span>
            <span>Month 4</span>
            <span>Month 5</span>
          </div>
        </div>
      </div>

      {/* Subtabs Selector: Performance, Trade Log (35), Parameters */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="flex border-b border-slate-800 bg-slate-950/60 p-1">
          <button
            onClick={() => setActiveSubtab('performance')}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
              activeSubtab === 'performance'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Performance
          </button>
          <button
            onClick={() => setActiveSubtab('trades')}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
              activeSubtab === 'trades'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Trade Log (35)
          </button>
          <button
            onClick={() => setActiveSubtab('params')}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition cursor-pointer ${
              activeSubtab === 'params'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Parameters
          </button>
        </div>

        {/* Subtab 1: Performance */}
        {activeSubtab === 'performance' && (
          <div className="p-5 space-y-4">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-3.5 h-3.5 text-emerald-400" />
              Comprehensive Simulation Breakdown
            </h4>

            <div className="space-y-2 text-xs divide-y divide-slate-800/80 font-mono">
              <div className="flex items-center justify-between py-2">
                <span className="text-slate-400">Initial Starting Capital:</span>
                <span className="font-bold text-white">₹ 10,00,000</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-slate-400">Final Ending Capital:</span>
                <span className="font-bold text-emerald-400">₹ 18,48,582.94</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-slate-400">Total Indian Taxes & Brokerage:</span>
                <span className="font-bold text-rose-400">- ₹ 44,136</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-slate-400">Average Return Per Trade:</span>
                <span className="font-bold text-emerald-400">+4.6%</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-slate-400">Holding Horizon Average:</span>
                <span className="font-bold text-slate-200">12 - 28 Days</span>
              </div>
            </div>

            <div className="pt-3 flex flex-col sm:flex-row gap-3">
              <button
                onClick={onDeployToPaper}
                className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Deploy to Live Paper Terminal</span>
              </button>
            </div>
          </div>
        )}

        {/* Subtab 2: Trade Log */}
        {activeSubtab === 'trades' && (
          <div className="divide-y divide-slate-800 text-xs font-mono">
            {tradeLogs.map((tr) => (
              <div key={tr.id} className="p-3.5 flex items-center justify-between hover:bg-slate-800/30 transition">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{tr.symbol}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-bold">
                      {tr.type}
                    </span>
                    <span className="text-slate-400 text-[11px]">{tr.date}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Entry: {tr.entry} → Exit: {tr.exit} • {tr.duration}
                  </p>
                </div>
                <div className="text-right">
                  <span className={`font-bold ${tr.outcome === 'WIN' ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {tr.pnl}
                  </span>
                  <span className="text-[11px] text-slate-400 block">{tr.returnPct}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Subtab 3: Parameters */}
        {activeSubtab === 'params' && (
          <div className="p-5 space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono">
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">RVOL Threshold</span>
                <span className="font-bold text-white">&gt;= 1.5x (Surge 2.0x)</span>
              </div>
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Daily Candle Close</span>
                <span className="font-bold text-white">Strictly Above Resistance</span>
              </div>
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">DMA Trend Filter</span>
                <span className="font-bold text-white">Price &gt; 20 DMA &gt; 50 DMA</span>
              </div>
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase block">Risk Per Trade</span>
                <span className="font-bold text-white">1.0% Capital Cap</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
