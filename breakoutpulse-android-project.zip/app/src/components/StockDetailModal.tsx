import React from 'react';
import { X, CheckCircle2, TrendingUp, ShieldAlert, Sparkles, Plus, Wallet } from 'lucide-react';
import { StockBreakout } from '../types/trading';
import { formatINR } from '../utils/calculations';
import { DailyChart } from './DailyChart';

interface StockDetailModalProps {
  stock: StockBreakout | null;
  onClose: () => void;
  onSyncToTasks: (stock: StockBreakout) => void;
  onOpenTrade: (stock: StockBreakout) => void;
  onOpenAiPrompt: (stock: StockBreakout) => void;
}

export const StockDetailModal: React.FC<StockDetailModalProps> = ({
  stock,
  onClose,
  onSyncToTasks,
  onOpenTrade,
  onOpenAiPrompt,
}) => {
  if (!stock) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-2xl shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-bold text-white tracking-tight">{stock.symbol}</h3>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {stock.marketCap}
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                Score: {stock.score}/100
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{stock.name} • {stock.sector}</p>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition cursor-pointer p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Price & Chart */}
        <div className="flex items-baseline justify-between">
          <div className="font-mono text-2xl font-bold text-white">
            {formatINR(stock.currentPrice)}
          </div>
          <span
            className={`text-sm font-semibold ${
              stock.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {stock.changePercent >= 0 ? '+' : ''}{stock.changePercent}%
          </span>
        </div>

        <DailyChart
          candles={stock.candles}
          resistance={stock.resistanceLevel}
          support={stock.supportLevel}
          symbol={stock.symbol}
        />

        {/* Quant & Technical Attributes */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 font-mono text-xs">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase block font-sans">Relative Vol (RVOL)</span>
            <span className="text-sm font-bold text-cyan-400">{stock.rvol}x</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase block font-sans">NSE Delivery %</span>
            <span className="text-sm font-bold text-emerald-400">{stock.deliveryPercent}%</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase block font-sans">Pivot Resistance</span>
            <span className="text-sm font-bold text-white">{formatINR(stock.resistanceLevel)}</span>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 uppercase block font-sans">Support Floor</span>
            <span className="text-sm font-bold text-amber-400">{formatINR(stock.supportLevel)}</span>
          </div>
        </div>

        {/* Catalyst Note */}
        <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 text-xs space-y-1">
          <span className="font-semibold text-emerald-400 block uppercase text-[10px]">Institutional Catalyst:</span>
          <p className="text-slate-300 leading-relaxed">{stock.catalyst}</p>
        </div>

        {/* Rules */}
        <div className="text-xs space-y-1.5 bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
          <p className="text-slate-300">
            <span className="font-semibold text-emerald-400">Strict Confirmation:</span> {stock.confirmationRule}
          </p>
          <p className="text-slate-400">
            <span className="font-semibold text-rose-400">Invalidation Rule:</span> {stock.invalidationRule}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="pt-2 flex flex-wrap gap-2">
          <button
            onClick={() => {
              onSyncToTasks(stock);
              onClose();
            }}
            className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Sync to Tasks</span>
          </button>
          <button
            onClick={() => {
              onOpenTrade(stock);
              onClose();
            }}
            className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Wallet className="w-4 h-4 text-emerald-400" />
            <span>Place Paper Order</span>
          </button>
          <button
            onClick={() => {
              onOpenAiPrompt(stock);
              onClose();
            }}
            className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Prompt Studio</span>
          </button>
        </div>
      </div>
    </div>
  );
};
