import React from 'react';
import {
  Bell,
  RefreshCw,
  Radio,
  Shield,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface HeaderBarProps {
  viewMode: 'android' | 'expanded';
  setViewMode: (mode: 'android' | 'expanded') => void;
  onlineDevices: number;
  alertsCount: number;
  onOpenAlerts: () => void;
  indices?: { label: string; value: number; pct: number }[];
  isLive?: boolean;
  onConnect?: () => void;
  statusText?: string;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  viewMode,
  setViewMode,
  onlineDevices,
  alertsCount,
  onOpenAlerts,
  indices,
  isLive = false,
  onConnect,
  statusText,
}) => {
  const [audioAlerts, setAudioAlerts] = React.useState(true);
  const [isRefreshing, setIsRefreshing] = React.useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 600);
  };

  return (
    <header style={{ paddingTop: "env(safe-area-inset-top)" }} className="border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md sticky top-0 z-40">
      {/* Top Brand Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center font-black text-slate-950 text-lg shadow-lg shadow-emerald-500/20 tracking-tighter">
            BP
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-white tracking-tight">BreakoutPulse NSE</h1>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 uppercase tracking-wider">
                AI Trading & Task Sync
              </span>
            </div>
            <p className="hidden sm:block text-xs text-slate-400">
              Indian Stock Market Breakout Engine • Minervini VCP • MTF 30-40D • Real-time Sync
            </p>
          </div>
        </div>

        {/* Status Indicators & View Mode Toggle */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Market Status */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <div className="flex flex-col text-[11px] leading-tight">
              <span className="text-[9px] text-slate-500 font-semibold uppercase">NSE/BSE</span>
              <span className="text-emerald-400 font-medium">{isLive ? 'Live' : 'Demo'}</span>
            </div>
          </div>

          {/* Alerts Button */}
          <button
            onClick={onOpenAlerts}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-xs text-slate-300 transition cursor-pointer"
          >
            <Bell className="w-3.5 h-3.5 text-emerald-400" />
            <span>Alerts</span>
            <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/30">
              {alertsCount}
            </span>
          </button>

          {/* Sync status */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
            <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Sync: {onlineDevices} Device Online</span>
          </div>

        </div>
      </div>

      {/* Live Market Ticker & Mobile Status Bar Strip */}
      <div className="bg-slate-900/90 border-t border-slate-800/60 px-4 sm:px-6 lg:px-8 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          {/* Indices Real-time Ticker */}
          <div className="flex items-center gap-4 overflow-x-auto py-0.5 no-scrollbar text-xs font-mono">
            <div className="flex items-center gap-1.5 text-emerald-400 shrink-0">
              <span className={`w-1.5 h-1.5 rounded-full animate-pulse ${isLive ? 'bg-emerald-400' : 'bg-amber-400'}`} />
              <span className="text-slate-400 text-[10px] uppercase font-bold">{isLive ? 'UPSTOX:' : 'DEMO DATA:'}</span>
            </div>
            {(indices && indices.length ? indices : [
              { label: 'NIFTY', value: 24850.2, pct: 0.59 }, { label: 'SENSEX', value: 81480, pct: 0.51 },
              { label: 'BANKNIFTY', value: 52140.8, pct: 0.62 }, { label: 'INDIA VIX', value: 12.85, pct: -3.2 },
            ]).map((t, i) => (
              <React.Fragment key={t.label}>
                {i > 0 && <span className="text-slate-700">|</span>}
                <div className="flex items-center gap-1 shrink-0">
                  <span className="text-slate-300">{t.label}</span>
                  <span className={`font-semibold ${t.pct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{t.value.toLocaleString('en-IN', { maximumFractionDigits: 2 })}</span>
                  <span className={`text-[10px] ${t.pct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>({t.pct >= 0 ? '+' : ''}{t.pct.toFixed(2)}%)</span>
                </div>
              </React.Fragment>
            ))}
            {onConnect && !isLive && (
              <button onClick={onConnect} className="shrink-0 px-2.5 py-1 rounded-lg bg-emerald-500 text-slate-950 font-bold text-[11px] cursor-pointer">Connect Upstox</button>
            )}
            {statusText && <span className="shrink-0 text-[10px] text-slate-500">{statusText}</span>}

            <div className="flex items-center gap-2 pl-2 border-l border-slate-800 shrink-0">
              <button
                onClick={() => setAudioAlerts(!audioAlerts)}
                className="text-slate-400 hover:text-white transition cursor-pointer"
                title={audioAlerts ? 'Mute Audio Alerts' : 'Unmute Audio Alerts'}
              >
                {audioAlerts ? <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={handleRefresh}
                className="text-slate-400 hover:text-white transition cursor-pointer"
                title="Refresh Ticker Feed"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
