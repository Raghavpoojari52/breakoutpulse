import React from 'react';
import { Sparkles, BarChart3, Kanban, Terminal, Check, ArrowRight } from 'lucide-react';
import { ARCHETYPES, ProjectArchetype } from '../utils/appletParser';

interface ArchetypeSelectorProps {
  selectedArchetypeId: string;
  onSelectArchetype: (archetype: ProjectArchetype) => void;
}

const ICONS_MAP: Record<string, React.ReactNode> = {
  Sparkles: <Sparkles className="w-5 h-5 text-indigo-400" />,
  BarChart3: <BarChart3 className="w-5 h-5 text-emerald-400" />,
  Kanban: <Kanban className="w-5 h-5 text-amber-400" />,
  Terminal: <Terminal className="w-5 h-5 text-sky-400" />,
};

export const ArchetypeSelector: React.FC<ArchetypeSelectorProps> = ({
  selectedArchetypeId,
  onSelectArchetype,
}) => {
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h3 className="text-lg font-bold text-white tracking-tight">Select Project Archetype</h3>
          <p className="text-xs text-slate-400">Choose the foundation that most closely matches your reference app</p>
        </div>
        <span className="text-xs font-medium text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-md self-start border border-slate-700">
          4 Recommended Blueprints
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {ARCHETYPES.map((arch) => {
          const isSelected = selectedArchetypeId === arch.id;
          return (
            <div
              key={arch.id}
              onClick={() => onSelectArchetype(arch)}
              className={`p-5 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between relative overflow-hidden group ${
                isSelected
                  ? 'bg-slate-800/90 border-indigo-500 shadow-xl shadow-indigo-500/10 ring-1 ring-indigo-500/50'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-xl bg-slate-800 border border-slate-700/60">
                    {ICONS_MAP[arch.icon] || <Sparkles className="w-5 h-5 text-indigo-400" />}
                  </div>
                  <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                    {arch.badge}
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-semibold text-white group-hover:text-indigo-300 transition">
                    {arch.name}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {arch.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800/80">
                  <span className="text-[10px] font-semibold tracking-wider text-slate-500 uppercase">Includes:</span>
                  <ul className="mt-1.5 space-y-1">
                    {arch.defaultFeatures.slice(0, 3).map((feat, idx) => (
                      <li key={idx} className="text-[11px] text-slate-300 flex items-center gap-1.5">
                        <span className="w-1 h-1 rounded-full bg-indigo-400" />
                        <span className="truncate">{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-4 pt-3 flex items-center justify-between text-xs font-medium">
                {isSelected ? (
                  <span className="text-indigo-400 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Selected
                  </span>
                ) : (
                  <span className="text-slate-400 group-hover:text-slate-200 flex items-center gap-1">
                    Load Preview <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition" />
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
