import React from 'react';
import {
  Layers,
  LineChart,
  TrendingUp,
  Award,
  BookOpen,
  Bot,
  CheckSquare,
  Activity,
  Share2,
} from 'lucide-react';

export type TabKey =
  | 'scanner'
  | 'backtest'
  | 'trade'
  | 'analytics'
  | 'journal'
  | 'aiprompts'
  | 'tasks'
  | 'indexscalp'
  | 'synchub';

interface BottomNavProps {
  activeTab: TabKey;
  setActiveTab: (tab: TabKey) => void;
  tasksCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  tasksCount,
}) => {
  const tabs: { key: TabKey; label: string; ariaLabel: string; icon: React.ReactNode; badge?: number }[] = [
    { key: 'scanner', label: 'Scanner', ariaLabel: 'Breakout Scanner', icon: <Layers className="w-4 h-4" /> },
    { key: 'backtest', label: 'Backtest', ariaLabel: 'Strategy Backtesting', icon: <LineChart className="w-4 h-4" /> },
    { key: 'trade', label: 'Trade', ariaLabel: 'Paper and Real Trading Terminal', icon: <TrendingUp className="w-4 h-4" /> },
    { key: 'analytics', label: 'Analytics', ariaLabel: 'Closed Tasks Performance Dashboard', icon: <Award className="w-4 h-4" /> },
    { key: 'journal', label: 'Journal', ariaLabel: 'Trade Journal & Screenshot Logs', icon: <BookOpen className="w-4 h-4" /> },
    { key: 'aiprompts', label: 'AI Prompts', ariaLabel: 'AI Prompts Studio', icon: <Bot className="w-4 h-4" /> },
    { key: 'tasks', label: 'Tasks', ariaLabel: 'Synced Trading Tasks', icon: <CheckSquare className="w-4 h-4" />, badge: tasksCount },
    { key: 'indexscalp', label: 'Index Scalp', ariaLabel: 'Index Scalping', icon: <Activity className="w-4 h-4" /> },
    { key: 'synchub', label: 'Sync Hub', ariaLabel: 'Sync & Multi-Device', icon: <Share2 className="w-4 h-4" /> },
  ];

  return (
    <nav
      aria-label="Main Navigation"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      className="fixed bottom-0 left-0 right-0 bg-slate-950/95 backdrop-blur-lg border-t border-slate-800/80 z-40 max-w-7xl mx-auto"
    >
      <div className="flex items-center justify-around py-1.5 px-1 sm:px-4 overflow-x-auto no-scrollbar">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              aria-label={tab.ariaLabel}
              className={`flex flex-col items-center justify-center gap-0.5 py-1 px-1.5 sm:px-3 rounded-xl transition-all shrink-0 cursor-pointer relative ${
                isActive
                  ? 'text-emerald-400 font-bold bg-emerald-500/10'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                {tab.icon}
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 w-3.5 h-3.5 bg-emerald-500 text-slate-950 font-black text-[9px] rounded-full flex items-center justify-center font-mono">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] tracking-tight whitespace-nowrap">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
