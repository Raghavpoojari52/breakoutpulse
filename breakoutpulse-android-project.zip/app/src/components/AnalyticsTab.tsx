import React from 'react';
import {
  BarChart3,
  TrendingUp,
  PieChart,
  Target,
  Award,
  ShieldCheck,
  CheckCircle2,
  Calendar,
} from 'lucide-react';
import { formatINR } from '../utils/calculations';

export const AnalyticsTab: React.FC = () => {
  return (
    <div className="space-y-5 pb-16">
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white">Closed Tasks & Performance Analytics</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Statistical distribution of verified NSE breakout setups, risk adherence, and edge metrics.
          </p>
        </div>
        <span className="text-[10px] font-mono px-2 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
          Updated: Today
        </span>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Total Realized P&L</span>
          <span className="text-xl font-mono font-bold text-emerald-400">+ ₹ 8,48,582</span>
          <span className="text-[11px] text-slate-400 block mt-0.5">+84.9% on capital</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Expectancy / Trade</span>
          <span className="text-xl font-mono font-bold text-white">+ ₹ 24,245</span>
          <span className="text-[11px] text-emerald-400 block mt-0.5">Edge positive</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Max Consecutive Wins</span>
          <span className="text-xl font-mono font-bold text-cyan-400">7 Trades</span>
          <span className="text-[11px] text-slate-400 block mt-0.5">Max Losses: 2</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">Discipline Adherence</span>
          <span className="text-xl font-mono font-bold text-emerald-400">94.2%</span>
          <span className="text-[11px] text-slate-400 block mt-0.5">Zero FOMO violations</span>
        </div>
      </div>

      {/* Sector Performance Distribution */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <PieChart className="w-4 h-4 text-emerald-400" />
          Sectoral Alpha Breakdown
        </h3>

        <div className="space-y-3">
          {[
            { sector: 'Electronics & EMS (Dixon, Amber)', pnl: '+ ₹ 3,12,000', winRate: '82%', share: 82, color: 'bg-emerald-500' },
            { sector: 'Capital Goods & Infra (L&T, KEC)', pnl: '+ ₹ 2,45,000', winRate: '75%', share: 75, color: 'bg-cyan-500' },
            { sector: 'Telecom & Tech (Bharti, Tata Tech)', pnl: '+ ₹ 1,84,000', winRate: '70%', share: 70, color: 'bg-indigo-500' },
            { sector: 'Retail & Consumer (Trent, Titan)', pnl: '+ ₹ 1,42,000', winRate: '68%', share: 68, color: 'bg-amber-500' },
          ].map((sec, idx) => (
            <div key={idx} className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-300 font-sans">{sec.sector}</span>
                <span className="text-emerald-400 font-bold">{sec.pnl} ({sec.winRate} Win)</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div className={`${sec.color} h-full rounded-full`} style={{ width: `${sec.share}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Breakout Score vs Win Rate correlation */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3 font-mono text-xs">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2 font-sans">
          <Award className="w-4 h-4 text-cyan-400" />
          Breakout Score Correlation Matrix
        </h3>
        <p className="text-slate-400 text-xs font-sans">
          Historical win rate segmented by BreakoutPulse algorithmic setup score:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase text-emerald-400 font-bold block">Score 90 - 100</span>
            <span className="text-base font-bold text-white mt-1 block">78.4% Win Rate</span>
            <span className="text-[11px] text-slate-400">Avg Return: +8.2%</span>
          </div>
          <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase text-cyan-400 font-bold block">Score 75 - 89</span>
            <span className="text-base font-bold text-white mt-1 block">64.1% Win Rate</span>
            <span className="text-[11px] text-slate-400">Avg Return: +4.1%</span>
          </div>
          <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase text-rose-400 font-bold block">Score &lt; 70</span>
            <span className="text-base font-bold text-white mt-1 block">38.0% Win Rate</span>
            <span className="text-[11px] text-slate-400">Negative EV (Filtered out)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
