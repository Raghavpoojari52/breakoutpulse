import React, { useState } from 'react';
import { Candle } from '../types/trading';

interface DailyChartProps {
  candles: Candle[];
  resistance: number;
  support: number;
  symbol: string;
}

export const DailyChart: React.FC<DailyChartProps> = ({ candles, resistance, support, symbol }) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!candles || candles.length === 0) return null;

  // Chart Dimensions
  const width = 640;
  const height = 180;
  const paddingBottom = 40; // reserved for volume
  const chartHeight = height - paddingBottom;

  // Price Bounds
  const allPrices = candles.flatMap((c) => [c.high, c.low, c.dma20, c.dma50, resistance, support]);
  const minPrice = Math.min(...allPrices) * 0.985;
  const maxPrice = Math.max(...allPrices) * 1.015;
  const priceRange = maxPrice - minPrice || 1;

  // Volume Bounds
  const maxVolume = Math.max(...candles.map((c) => c.volume)) * 1.2 || 1;

  const getY = (val: number) => {
    return chartHeight - ((val - minPrice) / priceRange) * chartHeight + 10;
  };

  const candleWidth = width / candles.length;

  // Generate DMA Path lines
  const dma20Path = candles
    .map((c, i) => `${i === 0 ? 'M' : 'L'} ${(i + 0.5) * candleWidth} ${getY(c.dma20)}`)
    .join(' ');

  const dma50Path = candles
    .map((c, i) => `${i === 0 ? 'M' : 'L'} ${(i + 0.5) * candleWidth} ${getY(c.dma50)}`)
    .join(' ');

  const resY = getY(resistance);
  const supY = getY(support);

  const hoveredCandle = hoveredIndex !== null ? candles[hoveredIndex] : null;

  return (
    <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-3 select-none">
      <div className="flex flex-wrap items-center justify-between text-xs text-slate-400 mb-2 gap-2">
        <span className="font-semibold text-slate-300">Daily Chart (NSE)</span>
        <div className="flex items-center gap-3 font-mono text-[11px]">
          <span className="flex items-center gap-1 text-amber-400">
            <span className="w-3 h-0.5 bg-amber-400 inline-block" /> 20 DMA
          </span>
          <span className="flex items-center gap-1 text-blue-400">
            <span className="w-3 h-0.5 bg-blue-400 inline-block" /> 50 DMA
          </span>
          <span className="flex items-center gap-1 text-cyan-400">
            <span className="w-3 h-0.5 border-t border-dashed border-cyan-400 inline-block" /> Res: Rs.{resistance}
          </span>
        </div>
      </div>

      <div className="relative overflow-hidden w-full h-[180px]">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full overflow-visible"
          preserveAspectRatio="none"
          onMouseLeave={() => setHoveredIndex(null)}
        >
          {/* Grid lines */}
          <line x1="0" y1={resY} x2={width} y2={resY} stroke="#06b6d4" strokeDasharray="3 3" strokeWidth="1" opacity="0.6" />
          <line x1="0" y1={supY} x2={width} y2={supY} stroke="#f59e0b" strokeDasharray="3 3" strokeWidth="1" opacity="0.6" />

          {/* Labels for resistance and support */}
          <text x="6" y={resY - 4} fill="#06b6d4" fontSize="10" fontFamily="monospace" opacity="0.9">
            Pivot/Res Rs.{resistance}
          </text>
          <text x="6" y={supY - 4} fill="#f59e0b" fontSize="10" fontFamily="monospace" opacity="0.9">
            Sup Rs.{support}
          </text>

          {/* Volume Bars */}
          {candles.map((c, i) => {
            const isUp = c.close >= c.open;
            const barHeight = (c.volume / maxVolume) * paddingBottom;
            const x = i * candleWidth + candleWidth * 0.2;
            const y = height - barHeight;
            const barW = candleWidth * 0.6;

            return (
              <rect
                key={`vol-${i}`}
                x={x}
                y={y}
                width={barW}
                height={barHeight}
                fill={isUp ? '#10b981' : '#f43f5e'}
                opacity="0.35"
              />
            );
          })}

          {/* 50 DMA Line */}
          <path d={dma50Path} fill="none" stroke="#3b82f6" strokeWidth="1.5" opacity="0.8" />
          {/* 20 DMA Line */}
          <path d={dma20Path} fill="none" stroke="#f59e0b" strokeWidth="1.5" opacity="0.9" />

          {/* Candlesticks */}
          {candles.map((c, i) => {
            const isUp = c.close >= c.open;
            const xCenter = (i + 0.5) * candleWidth;
            const highY = getY(c.high);
            const lowY = getY(c.low);
            const openY = getY(c.open);
            const closeY = getY(c.close);
            const bodyTop = Math.min(openY, closeY);
            const bodyHeight = Math.max(Math.abs(closeY - openY), 1.5);
            const bodyWidth = candleWidth * 0.55;

            return (
              <g
                key={`candle-${i}`}
                className="cursor-pointer"
                onMouseEnter={() => setHoveredIndex(i)}
              >
                {/* Wick */}
                <line
                  x1={xCenter}
                  y1={highY}
                  x2={xCenter}
                  y2={lowY}
                  stroke={isUp ? '#10b981' : '#f43f5e'}
                  strokeWidth="1.2"
                />
                {/* Body */}
                <rect
                  x={xCenter - bodyWidth / 2}
                  y={bodyTop}
                  width={bodyWidth}
                  height={bodyHeight}
                  fill={isUp ? '#10b981' : '#f43f5e'}
                  rx="1"
                />
              </g>
            );
          })}

          {/* Crosshair indicator */}
          {hoveredIndex !== null && (
            <line
              x1={(hoveredIndex + 0.5) * candleWidth}
              y1="0"
              x2={(hoveredIndex + 0.5) * candleWidth}
              y2={height}
              stroke="#94a3b8"
              strokeDasharray="2 2"
              strokeWidth="1"
            />
          )}
        </svg>

        {hoveredCandle && (
          <div className="absolute right-2 top-2 bg-slate-900/95 border border-slate-700 rounded px-2 py-1 text-[10px] font-mono text-slate-300 shadow-lg pointer-events-none z-10 flex gap-2">
            <span>O: ₹{hoveredCandle.open}</span>
            <span>H: ₹{hoveredCandle.high}</span>
            <span>L: ₹{hoveredCandle.low}</span>
            <span className={hoveredCandle.close >= hoveredCandle.open ? 'text-emerald-400' : 'text-rose-400'}>
              C: ₹{hoveredCandle.close}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
