import React from 'react';
import { Layers, ShieldCheck, Sparkles, ExternalLink } from 'lucide-react';

interface HeaderProps {
  detectedId: string;
}

export const Header: React.FC<HeaderProps> = ({ detectedId }) => {
  return (
    <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-blue-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 text-white font-bold">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-semibold text-white tracking-tight">AI Studio Bridge</h1>
              <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                Workspace
              </span>
            </div>
            <p className="text-xs text-slate-400">Reconstruct, scaffold & iterate your Google AI Studio app</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {detectedId && (
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs font-mono text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-slate-400">Ref App:</span>
              <span className="text-indigo-300">{detectedId.slice(0, 8)}...{detectedId.slice(-4)}</span>
            </div>
          )}

          <a
            href="https://ai.google.dev/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 transition"
          >
            <span>Docs</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </header>
  );
};
