import React, { useState } from 'react';
import {
  Share2,
  RefreshCw,
  Smartphone,
  Laptop,
  CheckCircle2,
  Download,
  Upload,
  Copy,
  Check,
  Shield,
  Zap,
} from 'lucide-react';
import { TradingTask } from '../types/trading';

interface SyncHubTabProps {
  tasks: TradingTask[];
  onImportTasks: (tasks: TradingTask[]) => void;
  onlineDevices: number;
}

export const SyncHubTab: React.FC<SyncHubTabProps> = ({
  tasks,
  onImportTasks,
  onlineDevices,
}) => {
  const [pairingCode, setPairingCode] = useState('BP-7894-NSE');
  const [copied, setCopied] = useState(false);
  const [broadcastActive, setBroadcastActive] = useState(true);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(pairingCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(tasks, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', 'breakoutpulse_tasks_backup.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-5 pb-16">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white">Sync Hub & Multi-Device Mesh</h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
              Zero-Server P2P
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Sync tasks, checklists, and order executions across your trading laptop and Android mobile device.
          </p>
        </div>
        <span className="text-xs font-mono px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
          Channel: active
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Pairing Code Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            Device Pairing Bridge
          </h3>
          <p className="text-xs text-slate-400">
            Open BreakoutPulse on your secondary mobile or monitor and enter this pairing key:
          </p>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="font-mono text-xl font-bold text-emerald-400 tracking-wider">
              {pairingCode}
            </span>
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-xs font-semibold text-white transition cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400 pt-1">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Currently connected: {onlineDevices} online device in your workspace session.</span>
          </div>
        </div>

        {/* JSON Export/Import Backup */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Download className="w-4 h-4 text-cyan-400" />
            Export & Backup Workstation
          </h3>
          <p className="text-xs text-slate-400">
            Download your active breakout watchlist, risk checklists, and paper trading orders as JSON:
          </p>

          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <button
              onClick={handleExportJSON}
              className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export {tasks.length} Tasks (JSON)</span>
            </button>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400 font-mono">
            <span>BroadcastChannel API: <span className="text-emerald-400">Supported (latency &lt; 1ms)</span></span>
          </div>
        </div>
      </div>
    </div>
  );
};
