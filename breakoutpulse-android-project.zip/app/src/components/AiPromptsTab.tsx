import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  RotateCcw,
  Bot,
  Copy,
  Check,
  Zap,
  ShieldCheck,
  TrendingUp,
  Sliders,
} from 'lucide-react';
import { MOCK_STOCKS } from '../data/mockStocks';
import { StockBreakout } from '../types/trading';

interface AiPromptsTabProps {
  initialStock?: StockBreakout;
}

export const AiPromptsTab: React.FC<AiPromptsTabProps> = ({ initialStock }) => {
  const [selectedSymbol, setSelectedSymbol] = useState(initialStock ? initialStock.symbol : 'LT');
  const [promptTemplate, setPromptTemplate] = useState('swing-thesis');
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(
    `### AI Swing Breakout Audit: LARSEN & TOUBRO (LT)

1. **Minervini Trend Template Check**: PASS (10/10)
   - Current Price (₹3,740) > 20 DMA (₹3,620) > 50 DMA (₹3,510) > 200 DMA (₹3,340).
   - Base stage: Consolidation pivot breakout at ₹3,780.

2. **Volume & Delivery Fingerprint**: PASS
   - Relative Volume (RVOL) is 1.73x against 20-day baseline.
   - NSE Delivery percentage is 54.2%, confirming institutional accumulation rather than day-trader churn.

3. **Risk-to-Reward & Trade Parameters**:
   - Optimal Entry: ₹3,761 - ₹3,780 on 15M candle confirmation.
   - Invalidating Stop Loss: Strictly ₹3,595 (risk of 4.3%).
   - Conservative Target 1: ₹4,319 (+14.8%).
   - Asymmetric Risk-Reward: 1:3.4.

4. **Actionable Checklist**:
   - [ ] Confirm daily close above ₹3,780 pivot.
   - [ ] Set GTT limit order with trailing stop on 50% position.`
  );
  const [copied, setCopied] = useState(false);

  const stock = MOCK_STOCKS.find((s) => s.symbol === selectedSymbol) || MOCK_STOCKS[0];

  const templates = [
    { id: 'swing-thesis', title: 'Deep Swing Thesis Generator', desc: 'Synthesize institutional catalyst, 20/50 DMA alignment, and risk-reward profile.' },
    { id: 'vcp-audit', title: 'Minervini VCP Pattern Auditor', desc: 'Assess contraction tightness, volume dry-up, and cheat entry confirmation.' },
    { id: 'multi-timeframe', title: 'MTF Confluence & Weekly Base', desc: 'Validate Daily, Weekly, and Monthly charts for sector-wide tailwinds.' },
    { id: 'risk-sizing', title: 'Capital Protection & Position Sizing', desc: 'Compute exact share sizing capped at 1% total portfolio risk.' },
  ];

  const handleGenerate = () => {
    setIsGenerating(true);
    setAiResponse(null);
    setTimeout(() => {
      setIsGenerating(false);
      setAiResponse(
        `### AI Deep Analysis: ${stock.name} (${stock.symbol})\n\n` +
        `• **Pattern Architecture**: Multi-week bullish consolidation testing ${stock.resistanceLevel} resistance.\n` +
        `• **Institutional Accumulation**: RVOL at ${stock.rvol}x with ${stock.deliveryPercent}% delivery backing.\n` +
        `• **Execution Rule**: ${stock.confirmationRule}\n` +
        `• **Risk Constraint**: Hard stop loss at ${stock.stopLoss} (${stock.invalidationRule}).\n` +
        `• **Primary Catalyst**: ${stock.catalyst}\n` +
        `• **Model Confidence Score**: ${stock.score}/100.`
      );
    }, 800);
  };

  const handleCopy = () => {
    if (aiResponse) {
      navigator.clipboard.writeText(aiResponse);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-5 pb-16">
      {/* Studio Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex items-start gap-3">
        <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 shrink-0">
          <Bot className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white">AI Prompts Studio for Indian Equities</h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 uppercase">
              Gemini Powered
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
            Run institutional quantitative prompts against verified NSE chart data, volatility contractions, and liquidity order blocks.
          </p>
        </div>
      </div>

      {/* Selector & Template Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Templates List */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
            Select Prompt Template
          </label>
          <div className="space-y-2">
            {templates.map((tpl) => (
              <div
                key={tpl.id}
                onClick={() => setPromptTemplate(tpl.id)}
                className={`p-3.5 rounded-xl border cursor-pointer transition ${
                  promptTemplate === tpl.id
                    ? 'bg-indigo-600/15 border-indigo-500/80 text-white'
                    : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold">{tpl.title}</h4>
                  {promptTemplate === tpl.id && <Sparkles className="w-3.5 h-3.5 text-indigo-400" />}
                </div>
                <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{tpl.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Stock Selector & Generator Panel */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <label className="text-[10px] uppercase font-semibold text-slate-500 block mb-1">
                  Target Scrip
                </label>
                <select
                  value={selectedSymbol}
                  onChange={(e) => setSelectedSymbol(e.target.value)}
                  className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {MOCK_STOCKS.map((s) => (
                    <option key={s.symbol} value={s.symbol}>
                      {s.symbol} - {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/20 transition cursor-pointer self-start sm:self-auto"
              >
                {isGenerating ? <RotateCcw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>{isGenerating ? 'Generating Analysis...' : 'Run Prompt on ' + selectedSymbol}</span>
              </button>
            </div>

            {/* Response Box */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 min-h-[260px] relative">
              <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800/80 mb-3">
                <span className="font-mono text-[11px] text-indigo-400">Model: Gemini 2.5 Flash</span>
                {aiResponse && (
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white transition cursor-pointer"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copied' : 'Copy Output'}</span>
                  </button>
                )}
              </div>

              {isGenerating ? (
                <div className="py-16 text-center space-y-2">
                  <RotateCcw className="w-6 h-6 animate-spin text-indigo-400 mx-auto" />
                  <p className="text-xs text-slate-400">Synthesizing multi-timeframe order flow for {selectedSymbol}...</p>
                </div>
              ) : aiResponse ? (
                <div className="text-xs text-slate-200 whitespace-pre-line leading-relaxed font-sans">
                  {aiResponse}
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
