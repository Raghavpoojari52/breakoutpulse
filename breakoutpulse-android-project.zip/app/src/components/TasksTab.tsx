import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Zap,
  Trash2,
  Plus,
  Search,
  Filter,
  CheckSquare,
  Square,
  ArrowRight,
  Share2,
} from 'lucide-react';
import { TradingTask, TaskStatus } from '../types/trading';
import { formatINR } from '../utils/calculations';

interface TasksTabProps {
  tasks: TradingTask[];
  onUpdateStatus: (id: string, status: TaskStatus) => void;
  onToggleChecklist: (taskId: string, checkId: string) => void;
  onDeleteTask: (id: string) => void;
  onOpenNewTask: () => void;
  onOpenSyncHub: () => void;
}

export const TasksTab: React.FC<TasksTabProps> = ({
  tasks,
  onUpdateStatus,
  onToggleChecklist,
  onDeleteTask,
  onOpenNewTask,
  onOpenSyncHub,
}) => {
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const statusOptions: { key: string; label: string }[] = [
    { key: 'ALL', label: 'All Tasks' },
    { key: 'ACTIVE', label: 'ACTIVE' },
    { key: 'PENDING', label: 'PENDING' },
    { key: 'TRIGGERED', label: 'TRIGGERED' },
    { key: 'EXECUTED', label: 'EXECUTED' },
    { key: 'TARGET HIT', label: 'TARGET HIT' },
    { key: 'INVALIDATED', label: 'INVALIDATED' },
  ];

  const filteredTasks = tasks.filter((t) => {
    if (statusFilter !== 'ALL' && t.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.symbol.toLowerCase().includes(q) ||
        t.title.toLowerCase().includes(q) ||
        t.notes.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-5 pb-16">
      {/* Real-time Sync Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">Real-Time Sync Active</h3>
              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase tracking-wider">
                SUB-MS CHANNEL
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Changes instantly synchronize across tabs, mobile devices, and terminals.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenSyncHub}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold transition cursor-pointer self-start sm:self-auto"
        >
          <Share2 className="w-3.5 h-3.5 text-cyan-400" />
          <span>Sync Hub</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search trading tasks, symbols, or notes..."
            className="w-full bg-slate-900/90 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* Status Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {statusOptions.map((opt) => (
            <button
              key={opt.key}
              onClick={() => setStatusFilter(opt.key)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                statusFilter === opt.key
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Task Cards List */}
      <div className="space-y-4">
        {filteredTasks.map((task) => (
          <div
            key={task.id}
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3 hover:border-slate-700/80 transition"
          >
            {/* Header: Symbol, Priority, Time, Status dropdown */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <span className="text-base font-bold text-emerald-400 font-mono">{task.symbol}</span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
                    task.priority === 'CRITICAL'
                      ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                      : task.priority === 'HIGH'
                      ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {task.priority}
                </span>
                <span className="text-xs text-slate-500 font-mono">{task.createdAt}</span>
              </div>

              <select
                value={task.status}
                onChange={(e) => onUpdateStatus(task.id, e.target.value as TaskStatus)}
                className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs font-bold text-emerald-400 focus:outline-none"
              >
                <option value="ACTIVE">ACTIVE</option>
                <option value="PENDING">PENDING</option>
                <option value="TRIGGERED">TRIGGERED</option>
                <option value="EXECUTED">EXECUTED</option>
                <option value="TARGET HIT">TARGET HIT</option>
                <option value="INVALIDATED">INVALIDATED</option>
              </select>
            </div>

            {/* Task Title */}
            <h4 className="text-sm font-bold text-white">{task.title}</h4>

            {/* Levels: Entry Zone, Stop Loss, Target */}
            <div className="grid grid-cols-3 gap-2 bg-slate-950/70 border border-slate-800/80 p-3 rounded-xl font-mono text-center">
              <div>
                <span className="text-[10px] uppercase font-semibold text-slate-500 block">Entry Zone</span>
                <span className="text-xs font-bold text-white">
                  ₹ {task.entryZoneMin} - ₹ {task.entryZoneMax}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-semibold text-slate-500 block">Stop Loss</span>
                <span className="text-xs font-bold text-rose-400">{formatINR(task.stopLoss)}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-semibold text-slate-500 block">Target</span>
                <span className="text-xs font-bold text-emerald-400">{formatINR(task.target)}</span>
              </div>
            </div>

            {/* Notes */}
            {task.notes && (
              <p className="text-xs text-slate-300 bg-slate-950/40 p-2.5 rounded-lg border border-slate-800/60 leading-relaxed">
                {task.notes}
              </p>
            )}

            {/* Execution Checklist (Real-time synced) */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Execution Checklist (Real-Time Synced)
              </span>
              <div className="space-y-1">
                {task.checklist.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => onToggleChecklist(task.id, item.id)}
                    className="flex items-center gap-2.5 p-2 rounded-lg bg-slate-950/60 hover:bg-slate-950 border border-slate-800/80 cursor-pointer text-xs text-slate-200 transition"
                  >
                    {item.completed ? (
                      <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-600 shrink-0" />
                    )}
                    <span className={item.completed ? 'line-through text-slate-500' : ''}>
                      {item.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] text-slate-500">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span>{task.syncedOrigin}</span>
              </div>

              <button
                onClick={() => onDeleteTask(task.id)}
                className="text-slate-500 hover:text-rose-400 transition cursor-pointer p-1"
                title="Delete Task"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}

        {filteredTasks.length === 0 && (
          <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h4 className="text-sm font-bold text-white">No tasks in this category</h4>
            <p className="text-xs text-slate-400">
              Click the green plus button to create a new breakout monitoring task.
            </p>
            <button
              onClick={onOpenNewTask}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-xl transition cursor-pointer inline-flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Create Trading Task</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
