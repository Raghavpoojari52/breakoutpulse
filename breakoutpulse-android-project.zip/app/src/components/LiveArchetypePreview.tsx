import React, { useState } from 'react';
import {
  Sparkles,
  BarChart3,
  Kanban,
  Terminal,
  Send,
  Image as ImageIcon,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  TrendingUp,
  Users,
  DollarSign,
  Activity,
  Plus,
  Play,
  RotateCcw,
  Copy,
  Check,
  Search,
  Filter,
} from 'lucide-react';

interface LiveArchetypePreviewProps {
  archetypeId: string;
}

export const LiveArchetypePreview: React.FC<LiveArchetypePreviewProps> = ({ archetypeId }) => {
  // Multimodal AI state
  const [promptInput, setPromptInput] = useState('Analyze this quarterly business presentation slide and extract key revenue growth drivers.');
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiOutput, setAiOutput] = useState<string | null>(
    '### Executive Summary Analysis\n\n1. **Core Growth Driver**: SaaS ARR expanded 38% YoY, led by enterprise tier expansion.\n2. **Retention Metric**: Net Revenue Retention (NRR) sustained at 124% across cohorts.\n3. **Recommendation**: Focus Q4 pipeline on multi-seat team workspace conversions.'
  );

  // SaaS state
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');
  const [filterQuery, setFilterQuery] = useState('');

  // Kanban state
  const [tasks, setTasks] = useState([
    { id: '1', title: 'Implement OAuth client flow', stage: 'in-progress', priority: 'High', assignee: 'Alex' },
    { id: '2', title: 'Design multimodal prompt builder', stage: 'done', priority: 'Medium', assignee: 'Taylor' },
    { id: '3', title: 'Add real-time metrics telemetry', stage: 'backlog', priority: 'Low', assignee: 'Sam' },
    { id: '4', title: 'Setup Firestore security rules', stage: 'in-progress', priority: 'High', assignee: 'Jordan' },
  ]);
  const [newTaskTitle, setNewTaskTitle] = useState('');

  // API Tester state
  const [selectedMethod, setSelectedMethod] = useState<'GET' | 'POST' | 'PUT'>('POST');
  const [endpointUrl, setEndpointUrl] = useState('/api/gemini/generate');
  const [responseCode, setResponseCode] = useState(200);
  const [apiTiming, setApiTiming] = useState('142ms');

  const handleSimulateAiRun = () => {
    setIsGenerating(true);
    setAiOutput(null);
    setTimeout(() => {
      setIsGenerating(false);
      setAiOutput(`### Generated Response for "${promptInput.slice(0, 30)}..."\n\n• Successfully synthesized response with multi-turn context.\n• Evaluated constraints and generated structured JSON output.\n• Latency: 215ms | Tokens: 480 | Model: Gemini 2.5 Flash.`);
    }, 900);
  };

  const handleMoveTask = (id: string, nextStage: string) => {
    setTasks(tasks.map((t) => (t.id === id ? { ...t, stage: nextStage } : t)));
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    setTasks([
      ...tasks,
      {
        id: String(Date.now()),
        title: newTaskTitle.trim(),
        stage: 'backlog',
        priority: 'Medium',
        assignee: 'You',
      },
    ]);
    setNewTaskTitle('');
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
            {archetypeId === 'ai-multimodal' && <Sparkles className="w-4 h-4" />}
            {archetypeId === 'saas-dashboard' && <BarChart3 className="w-4 h-4" />}
            {archetypeId === 'workflow-kanban' && <Kanban className="w-4 h-4" />}
            {archetypeId === 'developer-sandbox' && <Terminal className="w-4 h-4" />}
          </div>
          <div>
            <h3 className="text-base font-semibold text-white">Live Interactive Architecture Preview</h3>
            <p className="text-xs text-slate-400">Interact with the prototype interface designed for this blueprint</p>
          </div>
        </div>
        <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium self-start sm:self-auto flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          Interactive Demo Ready
        </span>
      </div>

      {/* RENDER ACTIVE PREVIEW */}

      {/* 1. Gemini Multimodal Studio */}
      {archetypeId === 'ai-multimodal' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 space-y-3">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                Multimodal Input Prompt
              </label>
              <div className="relative">
                <textarea
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Enter multimodal prompt..."
                />
                <div className="absolute right-3 bottom-3 flex items-center gap-2">
                  <span className="text-[11px] text-slate-500 font-mono">Gemini 2.5 Flash</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700 text-xs text-slate-300 cursor-pointer hover:bg-slate-750">
                    <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Attached: slide-deck.png (1.2MB)</span>
                  </div>
                </div>

                <button
                  onClick={handleSimulateAiRun}
                  disabled={isGenerating}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-medium rounded-lg flex items-center gap-1.5 shadow-md shadow-indigo-600/20 transition cursor-pointer"
                >
                  {isGenerating ? <RotateCcw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  <span>{isGenerating ? 'Generating...' : 'Run Gemini'}</span>
                </button>
              </div>

              {/* Output block */}
              <div className="mt-4 bg-slate-950/70 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800 mb-2">
                  <span className="font-medium text-slate-300">Model Output Stream</span>
                  <span className="font-mono text-[11px] text-indigo-400">Status: Complete</span>
                </div>
                {aiOutput ? (
                  <div className="text-xs text-slate-200 whitespace-pre-line leading-relaxed font-sans">
                    {aiOutput}
                  </div>
                ) : (
                  <div className="py-6 flex items-center justify-center text-xs text-slate-500 gap-2">
                    <RotateCcw className="w-4 h-4 animate-spin text-indigo-400" />
                    <span>Streaming tokens from Gemini endpoint...</span>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-4 space-y-3">
              <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Prompt Presets</h4>
              <div className="space-y-2">
                {[
                  'Extract tables and metrics into clean JSON',
                  'Identify UX anti-patterns in screenshot',
                  'Summarize key insights and recommendations',
                  'Generate code implementation in React',
                ].map((sample, idx) => (
                  <button
                    key={idx}
                    onClick={() => setPromptInput(sample)}
                    className="w-full text-left p-2.5 rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 text-xs text-slate-300 hover:text-white transition cursor-pointer"
                  >
                    "{sample}"
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. SaaS Dashboard */}
      {archetypeId === 'saas-dashboard' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {(['7d', '30d', '90d'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setTimeRange(r)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium cursor-pointer transition ${
                    timeRange === r
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Last {r}
                </button>
              ))}
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="Filter accounts..."
                className="bg-slate-950 border border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: 'Total Revenue', value: '$124,500', change: '+14.2%', icon: <DollarSign className="w-4 h-4 text-emerald-400" /> },
              { label: 'Active Users', value: '8,420', change: '+8.1%', icon: <Users className="w-4 h-4 text-blue-400" /> },
              { label: 'Conversion Rate', value: '3.64%', change: '+0.4%', icon: <TrendingUp className="w-4 h-4 text-indigo-400" /> },
              { label: 'Avg Latency', value: '84ms', change: '-12ms', icon: <Activity className="w-4 h-4 text-amber-400" /> },
            ].map((kpi, idx) => (
              <div key={idx} className="bg-slate-950/70 border border-slate-800 p-3.5 rounded-xl">
                <div className="flex items-center justify-between text-slate-400 mb-1.5">
                  <span className="text-xs">{kpi.label}</span>
                  {kpi.icon}
                </div>
                <div className="flex items-baseline justify-between">
                  <span className="text-lg font-bold text-white">{kpi.value}</span>
                  <span className="text-[11px] font-medium text-emerald-400">{kpi.change}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-slate-950/60 border border-slate-800 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <h4 className="text-xs font-semibold text-slate-200">Recent Enterprise Accounts</h4>
              <span className="text-[11px] text-slate-400 font-mono">Real-time sync</span>
            </div>
            <div className="divide-y divide-slate-800/60 text-xs">
              {[
                { name: 'Acme Cloud Labs', tier: 'Enterprise Tier', users: 140, mrr: '$4,200', status: 'Active' },
                { name: 'HyperScale AI', tier: 'Growth Team', users: 85, mrr: '$2,500', status: 'Active' },
                { name: 'Starlight Media', tier: 'Pro Studio', users: 32, mrr: '$950', status: 'Trial' },
              ]
                .filter((row) => row.name.toLowerCase().includes(filterQuery.toLowerCase()))
                .map((row, idx) => (
                  <div key={idx} className="px-4 py-3 flex items-center justify-between hover:bg-slate-800/30 transition">
                    <div>
                      <p className="font-medium text-white">{row.name}</p>
                      <p className="text-[11px] text-slate-400">{row.tier} • {row.users} seats</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-slate-200">{row.mrr}/mo</p>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        {row.status}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. Workflow Kanban */}
      {archetypeId === 'workflow-kanban' && (
        <div className="space-y-4">
          <form onSubmit={handleAddTask} className="flex gap-2">
            <input
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="Add a new task..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-xl flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Task</span>
            </button>
          </form>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              { key: 'backlog', title: 'Backlog', color: 'border-slate-700' },
              { key: 'in-progress', title: 'In Progress', color: 'border-indigo-500/40' },
              { key: 'done', title: 'Completed', color: 'border-emerald-500/40' },
            ].map((col) => {
              const colTasks = tasks.filter((t) => t.stage === col.key);
              return (
                <div key={col.key} className={`bg-slate-950/60 border ${col.color} rounded-xl p-3 space-y-2`}>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs font-semibold text-slate-300">
                    <span>{col.title}</span>
                    <span className="text-[10px] px-2 py-0.5 bg-slate-800 rounded-full text-slate-400">
                      {colTasks.length}
                    </span>
                  </div>

                  <div className="space-y-2 min-h-[140px]">
                    {colTasks.map((t) => (
                      <div
                        key={t.id}
                        className="bg-slate-900 border border-slate-800 p-3 rounded-lg shadow-sm space-y-2 hover:border-slate-700 transition"
                      >
                        <p className="text-xs font-medium text-slate-200">{t.title}</p>
                        <div className="flex items-center justify-between text-[10px] text-slate-400">
                          <span
                            className={`px-1.5 py-0.5 rounded ${
                              t.priority === 'High'
                                ? 'bg-rose-500/10 text-rose-400'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {t.priority}
                          </span>
                          <span>{t.assignee}</span>
                        </div>
                        <div className="flex gap-1 pt-1 border-t border-slate-800/60">
                          {col.key !== 'backlog' && (
                            <button
                              onClick={() => handleMoveTask(t.id, col.key === 'done' ? 'in-progress' : 'backlog')}
                              className="text-[10px] text-slate-400 hover:text-white px-1.5 py-0.5 bg-slate-800 rounded transition cursor-pointer"
                            >
                              ← Back
                            </button>
                          )}
                          {col.key !== 'done' && (
                            <button
                              onClick={() => handleMoveTask(t.id, col.key === 'backlog' ? 'in-progress' : 'done')}
                              className="text-[10px] text-indigo-400 hover:text-indigo-300 px-1.5 py-0.5 bg-slate-800 rounded ml-auto transition cursor-pointer"
                            >
                              Next →
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. Developer Sandbox */}
      {archetypeId === 'developer-sandbox' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            <select
              value={selectedMethod}
              onChange={(e) => setSelectedMethod(e.target.value as any)}
              className="bg-slate-950 border border-slate-700 text-xs font-mono font-bold text-indigo-400 rounded-xl px-3 py-2 focus:outline-none"
            >
              <option value="POST">POST</option>
              <option value="GET">GET</option>
              <option value="PUT">PUT</option>
            </select>
            <input
              type="text"
              value={endpointUrl}
              onChange={(e) => setEndpointUrl(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <button
              onClick={() => {
                setResponseCode(200);
                setApiTiming(`${Math.floor(Math.random() * 80 + 100)}ms`);
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium rounded-xl flex items-center gap-1.5 transition cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs">
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-2">
              <span className="text-[10px] uppercase font-semibold text-slate-500">Request Payload (JSON)</span>
              <pre className="text-slate-300 overflow-x-auto text-[11px] leading-relaxed">
{`{
  "contents": [
    { "role": "user", "parts": [{ "text": "Hello Gemini" }] }
  ],
  "generationConfig": {
    "temperature": 0.7,
    "maxOutputTokens": 1024
  }
}`}
              </pre>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-2">
              <div className="flex items-center justify-between text-[10px] uppercase font-semibold text-slate-500">
                <span>Response ({responseCode} OK)</span>
                <span className="text-emerald-400">{apiTiming}</span>
              </div>
              <pre className="text-emerald-300 overflow-x-auto text-[11px] leading-relaxed">
{`{
  "candidates": [
    {
      "content": {
        "parts": [{ "text": "Hi! Ready to assist your project." }]
      },
      "finishReason": "STOP"
    }
  ]
}`}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
