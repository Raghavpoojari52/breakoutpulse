import React, { useState } from 'react';
import { X, Plus, CheckSquare } from 'lucide-react';
import { TradingTask } from '../types/trading';
import { MOCK_STOCKS } from '../data/mockStocks';

interface NewTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveTask: (task: Omit<TradingTask, 'id' | 'createdAt'>) => void;
}

export const NewTaskModal: React.FC<NewTaskModalProps> = ({
  isOpen,
  onClose,
  onSaveTask,
}) => {
  const [symbol, setSymbol] = useState(MOCK_STOCKS[0].symbol);
  const [title, setTitle] = useState(`Monitor ${MOCK_STOCKS[0].symbol} Breakout Trigger`);
  const [priority, setPriority] = useState<'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'>('HIGH');
  const [entryMin, setEntryMin] = useState(MOCK_STOCKS[0].entryPrice * 0.99);
  const [entryMax, setEntryMax] = useState(MOCK_STOCKS[0].entryPrice * 1.01);
  const [stopLoss, setStopLoss] = useState(MOCK_STOCKS[0].stopLoss);
  const [target, setTarget] = useState(MOCK_STOCKS[0].target1);
  const [notes, setNotes] = useState('Wait for 15M candle close above resistance with RVOL > 1.5x.');

  if (!isOpen) return null;

  const handleStockChange = (sym: string) => {
    setSymbol(sym);
    const stock = MOCK_STOCKS.find((s) => s.symbol === sym);
    if (stock) {
      setTitle(`Monitor ${stock.symbol} Breakout Trigger at ₹${stock.resistanceLevel}`);
      setEntryMin(Number((stock.entryPrice * 0.99).toFixed(1)));
      setEntryMax(Number((stock.entryPrice * 1.01).toFixed(1)));
      setStopLoss(stock.stopLoss);
      setTarget(stock.target1);
      setNotes(`Confirmation: ${stock.confirmationRule}`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveTask({
      symbol,
      title,
      priority,
      status: 'ACTIVE',
      entryZoneMin: Number(entryMin),
      entryZoneMax: Number(entryMax),
      stopLoss: Number(stopLoss),
      target: Number(target),
      notes,
      syncedOrigin: 'Manual Terminal Entry',
      checklist: [
        { id: '1', text: `15-min candle closed above ₹${entryMin}`, completed: false },
        { id: '2', text: 'RVOL > 1.5x on breakout volume', completed: false },
        { id: '3', text: `Set hard GTT Stop Loss at ₹${stopLoss}`, completed: false },
        { id: '4', text: 'Position sized strictly within 2% total capital risk', completed: false },
      ],
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 w-full max-w-lg shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-base font-bold text-white">Add New Trading Task</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                Stock Symbol
              </label>
              <select
                value={symbol}
                onChange={(e) => handleStockChange(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                {MOCK_STOCKS.map((s) => (
                  <option key={s.symbol} value={s.symbol}>
                    {s.symbol} - {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value="CRITICAL">CRITICAL</option>
                <option value="HIGH">HIGH</option>
                <option value="MEDIUM">MEDIUM</option>
                <option value="LOW">LOW</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
              Task Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="grid grid-cols-3 gap-2 font-mono">
            <div>
              <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                Entry Min (₹)
              </label>
              <input
                type="number"
                value={entryMin}
                onChange={(e) => setEntryMin(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                Stop Loss (₹)
              </label>
              <input
                type="number"
                value={stopLoss}
                onChange={(e) => setStopLoss(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-rose-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                Target (₹)
              </label>
              <input
                type="number"
                value={target}
                onChange={(e) => setTarget(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-emerald-400 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
              Execution Rule & Catalyst Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="pt-2 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 font-semibold text-xs rounded-xl transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-emerald-500/20 transition cursor-pointer"
            >
              Save & Sync Task
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
