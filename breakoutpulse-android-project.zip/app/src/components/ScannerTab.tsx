import React, { useState } from 'react';
import {
  Zap,
  BarChart2,
  Repeat,
  Compass,
  ShieldAlert,
  Calendar,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ArrowRight,
  Plus,
  Check,
  ExternalLink,
} from 'lucide-react';
import { StockBreakout, StrategyType, MarketCap } from '../types/trading';
import { DailyChart } from './DailyChart';
import { formatINR, getRvolBadge } from '../utils/calculations';

interface ScannerTabProps {
  stocks: StockBreakout[];
  onSyncToTasks: (stock: StockBreakout) => void;
  onOpenAiPrompt: (stock: StockBreakout) => void;
  onOpenDetails: (stock: StockBreakout) => void;
  syncedSymbols: Set<string>;
}

export const ScannerTab: React.FC<ScannerTabProps> = ({
  stocks,
  onSyncToTasks,
  onOpenAiPrompt,
  onOpenDetails,
  syncedSymbols,
}) => {
  const [selectedStrategy, setSelectedStrategy] = useState<StrategyType>('all');
  const [selectedCap, setSelectedCap] = useState<MarketCap>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlyAlertsMet, setOnlyAlertsMet] = useState(false);

  const strategies: { id: StrategyType; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: 'All Breakouts', icon: <Zap className="w-3.5 h-3.5" /> },
    { id: 'complete-breakout', label: 'Complete Breakout', icon: <Zap className="w-3.5 h-3.5 text-emerald-400" /> },
    { id: 'volume-breakout', label: 'Volume Breakout (RVOL > 2x)', icon: <BarChart2 className="w-3.5 h-3.5 text-cyan-400" /> },
    { id: 'retest', label: 'Retest Strategy', icon: <Repeat className="w-3.5 h-3.5 text-indigo-400" /> },
    { id: 'early-squeeze', label: 'Early Squeeze', icon: <Compass className="w-3.5 h-3.5 text-rose-400" /> },
    { id: 'vcp', label: 'VCP (Minervini)', icon: <ShieldAlert className="w-3.5 h-3.5 text-blue-400" /> },
    { id: 'mtf-30-40', label: 'MTF 30-40 Days', icon: <Calendar className="w-3.5 h-3.5 text-amber-400" /> },
  ];

  const filteredStocks = stocks.filter((s) => {
    // Strategy Filter
    if (selectedStrategy !== 'all' && s.strategy !== selectedStrategy) return false;
    // Cap Filter
    if (selectedCap !== 'ALL' && s.marketCap !== selectedCap) return false;
    // Only Alerts Met
    if (onlyAlertsMet && s.setupStatus !== 'SETUP READY') return false;
    // Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        s.symbol.toLowerCase().includes(q) ||
        s.name.toLowerCase().includes(q) ||
        s.sector.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-5 pb-16">
      {/* Strategy Selector Pills Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        {strategies.map((st) => {
          const isActive = selectedStrategy === st.id;
          return (
            <button
              key={st.id}
              onClick={() => setSelectedStrategy(st.id)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                isActive
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-lg shadow-emerald-500/20'
                  : 'bg-slate-900/90 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
              }`}
            >
              {st.icon}
              <span>{st.label}</span>
            </button>
          );
        })}
      </div>

      {/* Search and Cap Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search NSE stock or sector (e.g. Bharti, EMS, Dixon)..."
            className="w-full bg-slate-900/90 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* Market Cap & Alerts Filters */}
        <div className="flex items-center gap-2 overflow-x-auto">
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5 text-xs">
            {(['ALL', 'LARGE', 'MID', 'SMALL'] as const).map((cap) => (
              <button
                key={cap}
                onClick={() => setSelectedCap(cap)}
                className={`px-3 py-1 rounded-lg font-medium transition cursor-pointer text-xs ${
                  selectedCap === cap
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {cap === 'ALL' ? 'All Caps' : cap}
              </button>
            ))}
          </div>

          <button
            onClick={() => setOnlyAlertsMet(!onlyAlertsMet)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition cursor-pointer whitespace-nowrap ${
              onlyAlertsMet
                ? 'bg-emerald-500/15 border-emerald-500 text-emerald-400 font-semibold'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Criteria Alerts Met</span>
          </button>
        </div>
      </div>

      {/* Description Banner */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 flex items-start gap-3">
        <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
          <Sparkles className="w-4 h-4" />
        </div>
        <div>
          <h2 className="text-xs font-bold text-white tracking-wide uppercase">
            Complete Swing Breakout Scanner
          </h2>
          <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
            Analyzes trend structure, 20/50/200 DMA alignment, consolidation tightness, and volume expansion with verified NSE data. Never fabricates levels.
          </p>
        </div>
      </div>

      {/* Stock Cards Grid */}
      <div className="space-y-5">
        {filteredStocks.map((stock) => {
          const isSynced = syncedSymbols.has(stock.symbol);
          const rvolBadge = getRvolBadge(stock.rvol);
          const isReady = stock.setupStatus === 'SETUP READY';

          return (
            <div
              key={stock.symbol}
              className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4 hover:border-slate-700/80 transition"
            >
              {/* Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-white tracking-tight">{stock.symbol}</h3>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                      {stock.marketCap}
                    </span>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${rvolBadge.color}`}>
                      {rvolBadge.label}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">{stock.name}</p>
                </div>

                <div className="text-right flex sm:flex-col items-baseline sm:items-end justify-between">
                  <div className="flex items-center gap-1 font-mono text-lg font-bold text-white">
                    <span>{formatINR(stock.currentPrice)}</span>
                  </div>
                  <span
                    className={`text-xs font-semibold ${
                      stock.changePercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {stock.changePercent >= 0 ? '+' : ''}
                    {stock.changePercent.toFixed(2)}%
                  </span>
                </div>
              </div>

              {/* Status and Score Row */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-xs font-bold px-2.5 py-1 rounded-lg border ${
                      isReady
                        ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                        : 'bg-slate-800/80 text-slate-400 border-slate-700'
                    }`}
                  >
                    {stock.setupStatus}
                  </span>

                  {isReady && stock.buyAlertPercent > 0 && (
                    <span className="flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      BUY ALERT ({stock.buyAlertPercent}%)
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-slate-400">Score:</span>
                  <span
                    className={`font-mono font-bold px-2 py-0.5 rounded ${
                      stock.score >= 85
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : stock.score >= 70
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {stock.score}/100
                  </span>
                </div>
              </div>

              {/* Candlestick & Volume Chart */}
              <DailyChart
                candles={stock.candles}
                resistance={stock.resistanceLevel}
                support={stock.supportLevel}
                symbol={stock.symbol}
              />

              {/* Levels Grid: Entry, Stop Loss, Target 1, R:R */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-slate-950/70 border border-slate-800/80 p-3 rounded-xl font-mono text-center">
                <div className="border-r border-slate-800/80 pr-2">
                  <span className="text-[10px] uppercase font-semibold text-slate-500 block">Entry</span>
                  <span className="text-xs font-bold text-white">{formatINR(stock.entryPrice)}</span>
                </div>
                <div className="sm:border-r border-slate-800/80 pr-2">
                  <span className="text-[10px] uppercase font-semibold text-slate-500 block">Stop Loss</span>
                  <span className="text-xs font-bold text-rose-400">{formatINR(stock.stopLoss)}</span>
                </div>
                <div className="border-r border-slate-800/80 pr-2 pt-2 sm:pt-0">
                  <span className="text-[10px] uppercase font-semibold text-slate-500 block">Target 1</span>
                  <span className="text-xs font-bold text-emerald-400">{formatINR(stock.target1)}</span>
                </div>
                <div className="pt-2 sm:pt-0">
                  <span className="text-[10px] uppercase font-semibold text-slate-500 block">R:R</span>
                  <span className="text-xs font-bold text-cyan-400">{stock.riskReward}</span>
                </div>
              </div>

              {/* Confirmation & Invalidation text */}
              <div className="text-xs space-y-1 bg-slate-950/40 p-3 rounded-xl border border-slate-800/60 leading-relaxed">
                <p className="text-slate-300">
                  <span className="font-semibold text-emerald-400">Confirmation:</span>{' '}
                  {stock.confirmationRule}
                </p>
                <p className="text-slate-400">
                  <span className="font-semibold text-rose-400">Invalidation:</span>{' '}
                  {stock.invalidationRule}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
                <button
                  onClick={() => onSyncToTasks(stock)}
                  className={`flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                    isSynced
                      ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'
                      : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  }`}
                  aria-label={`Add ${stock.symbol} to synced tasks`}
                >
                  {isSynced ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                  <span>{isSynced ? 'Synced to Tasks' : 'Sync to Tasks'}</span>
                </button>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => onOpenAiPrompt(stock)}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-medium transition cursor-pointer"
                    aria-label={`Run AI Prompt on ${stock.symbol}`}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>AI Prompt</span>
                  </button>

                  <button
                    onClick={() => onOpenDetails(stock)}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-medium transition cursor-pointer"
                    aria-label={`View deep dive for ${stock.symbol}`}
                  >
                    <span>Details</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {filteredStocks.length === 0 && (
          <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-2">
            <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto" />
            <h4 className="text-sm font-semibold text-white">No breakout setups matching criteria</h4>
            <p className="text-xs text-slate-400">
              Try adjusting your strategy or market cap filters, or clearing the search query.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
