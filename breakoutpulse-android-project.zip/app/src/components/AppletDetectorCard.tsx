import React, { useState } from 'react';
import { Lock, AlertCircle, CheckCircle2, ArrowRight, RefreshCw, Copy, Check } from 'lucide-react';
import { parseAppletUrl, ParsedAppletUrl } from '../utils/appletParser';

interface AppletDetectorCardProps {
  currentUrl: string;
  onUrlChange: (newUrl: string) => void;
  parsed: ParsedAppletUrl;
}

export const AppletDetectorCard: React.FC<AppletDetectorCardProps> = ({
  currentUrl,
  onUrlChange,
  parsed,
}) => {
  const [inputValue, setInputValue] = useState(currentUrl);
  const [copied, setCopied] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUrlChange(inputValue);
  };

  const handleCopyId = () => {
    if (parsed.appletId) {
      navigator.clipboard.writeText(parsed.appletId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
      {/* Background glow accent */}
      <div className="absolute -right-20 -top-20 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-md text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" /> Google OAuth Protected
            </span>
            <span className="text-xs text-slate-400">Target Applet Detected</span>
          </div>

          <h2 className="text-xl font-bold text-white tracking-tight">
            Reference App: <span className="font-mono text-indigo-400">{parsed.appletId || '35c0861a-d004-412e-bf3d-6603a339123c'}</span>
          </h2>

          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            AI Studio applet URLs (<code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-indigo-300 font-mono">aistudio.google.com/apps/*</code>) 
            are secured by your personal Google account. Build sandboxes cannot sign in to private Google sessions, so we can build or replicate your app directly from your instructions, code snippets, or one of the curated starter archetypes below.
          </p>
        </div>

        <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-4 flex flex-col gap-3 min-w-[300px]">
          <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-700/60 pb-2">
            <span>Applet UUID</span>
            <button
              onClick={handleCopyId}
              className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300 transition"
              title="Copy UUID"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <p className="font-mono text-xs text-slate-200 break-all select-all">
            {parsed.appletId || '35c0861a-d004-412e-bf3d-6603a339123c'}
          </p>

          <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
            <div className="bg-slate-900/60 px-2 py-1 rounded border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">showAssistant:</span>
              <span className="text-emerald-400 font-medium">true</span>
            </div>
            <div className="bg-slate-900/60 px-2 py-1 rounded border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">showPreview:</span>
              <span className="text-emerald-400 font-medium">true</span>
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-6 pt-5 border-t border-slate-800/80 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Paste Google AI Studio applet URL or project ID..."
            className="w-full bg-slate-950/80 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent font-mono"
          />
        </div>
        <button
          type="submit"
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium rounded-xl flex items-center justify-center gap-2 transition shadow-md shadow-indigo-600/20 whitespace-nowrap cursor-pointer"
        >
          <span>Update Reference</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
