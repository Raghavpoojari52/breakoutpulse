import React, { useState, useEffect, useCallback } from 'react';
import { getToken, setToken, startLogin, listenForLogin, fetchIndices, refreshStocks, isBackendConfigured, UpstoxAuthError, type IndexTick } from './services/upstox';
import { HeaderBar } from './components/HeaderBar';
import { BottomNav, TabKey } from './components/BottomNav';
import { ScannerTab } from './components/ScannerTab';
import { BacktestTab } from './components/BacktestTab';
import { TradeTerminalTab } from './components/TradeTerminalTab';
import { AnalyticsTab } from './components/AnalyticsTab';
import { JournalTab } from './components/JournalTab';
import { AiPromptsTab } from './components/AiPromptsTab';
import { TasksTab } from './components/TasksTab';
import { IndexScalpTab } from './components/IndexScalpTab';
import { SyncHubTab } from './components/SyncHubTab';
import { NewTaskModal } from './components/NewTaskModal';
import { StockDetailModal } from './components/StockDetailModal';
import { MOCK_STOCKS } from './data/mockStocks';
import { TradingTask, StockBreakout, Position, Order, TaskStatus } from './types/trading';
import { Plus, Check, Bell, X } from 'lucide-react';

export default function App() {
  const [viewMode, setViewMode] = useState<'android' | 'expanded'>('expanded'); // native app always uses the full-screen layout
  const [activeTab, setActiveTab] = useState<TabKey>('scanner');
  const [onlineDevices, setOnlineDevices] = useState(1);
  // ---- Live market data (Upstox, user's own login) ----
  const [liveToken, setLiveToken] = useState<string | null>(getToken());
  const [indices, setIndices] = useState<IndexTick[]>([]);
  const [dataVersion, setDataVersion] = useState(0);
  const [liveStatus, setLiveStatus] = useState('');

  const loadLive = useCallback(async (tok: string) => {
    try {
      const [idx, n] = await Promise.all([fetchIndices(tok), refreshStocks(MOCK_STOCKS, tok)]);
      setIndices(idx); setDataVersion((v) => v + 1);
      setLiveStatus(`Updated ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })} · ${n} stocks`);
    } catch (e) {
      if (e instanceof UpstoxAuthError) { setToken(null); setLiveToken(null); setLiveStatus('Session expired – reconnect'); }
      else setLiveStatus('Live data unavailable');
    }
  }, []);

  useEffect(() => listenForLogin((t) => { setLiveToken(t); showToast('Connected to Upstox'); }, (m) => showToast(m)), []);
  useEffect(() => {
    if (!liveToken) return;
    loadLive(liveToken);
    const id = setInterval(() => loadLive(liveToken), 60_000);
    return () => clearInterval(id);
  }, [liveToken, loadLive]);
  const connectUpstox = () => {
    if (!isBackendConfigured()) { showToast('Live data server not configured'); return; }
    startLogin().catch(() => showToast('Could not open login'));
  };
  const liveProps = { indices, isLive: !!liveToken, onConnect: connectUpstox, statusText: liveStatus };
  void dataVersion;

  const [alertsCount, setAlertsCount] = useState(7);
  const [showAlertsBanner, setShowAlertsBanner] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Synced Trading Tasks
  const [tasks, setTasks] = useState<TradingTask[]>([
    {
      id: 'task-1',
      symbol: 'BHARTIARTL',
      priority: 'HIGH',
      createdAt: '02:05 am',
      status: 'ACTIVE',
      title: 'Monitor BHARTIARTL Breakout Trigger at ₹1,712',
      entryZoneMin: 1702,
      entryZoneMax: 1725,
      stopLoss: 1640,
      target: 1810,
      notes: 'Wait for 15M candle close above ₹1,712 with RVOL > 1.5x and 50%+ delivery. Industry tariff hike catalyst.',
      checklist: [
        { id: 'c1', text: '15-min candle closed above ₹1,710', completed: true },
        { id: 'c2', text: 'RVOL > 1.5x on breakout volume', completed: true },
        { id: 'c3', text: 'Set hard GTT Stop Loss at ₹1,640', completed: false },
        { id: 'c4', text: 'Position sized strictly within 2% total capital risk', completed: true },
      ],
      syncedOrigin: 'Synced via System',
    },
    {
      id: 'task-2',
      symbol: 'DIXON',
      priority: 'CRITICAL',
      createdAt: '10:05 pm',
      status: 'PENDING',
      title: 'Dixon Tech Institutional Breakout Follow-Through',
      entryZoneMin: 15350,
      entryZoneMax: 15550,
      stopLoss: 14100,
      target: 16800,
      notes: 'Q2 revenue up 133% YoY. High RVOL 2.39x. Watch for break above all-time pivot resistance ₹15,450.',
      checklist: [
        { id: 'c5', text: 'Daily close strictly above ₹15,450', completed: false },
        { id: 'c6', text: 'Verify institutional delivery > 55%', completed: false },
        { id: 'c7', text: 'Set GTT entry with trailing SL', completed: false },
      ],
      syncedOrigin: 'Synced via System',
    },
    {
      id: 'task-3',
      symbol: 'LT',
      priority: 'HIGH',
      createdAt: 'Yesterday',
      status: 'ACTIVE',
      title: 'L&T Capex Pivot Retest at ₹3,780',
      entryZoneMin: 3740,
      entryZoneMax: 3780,
      stopLoss: 3588,
      target: 4320,
      notes: '20/50/200 DMA bullish stack. Large Middle-East order flows support swing continuation.',
      checklist: [
        { id: 'c8', text: 'Price holding above 20 DMA support', completed: true },
        { id: 'c9', text: 'Volume expansion on pivot touch', completed: true },
      ],
      syncedOrigin: 'Synced via System',
    },
  ]);

  // Paper Trading Demat state
  const [positions, setPositions] = useState<Position[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  // Modals state
  const [isNewTaskModalOpen, setIsNewTaskModalOpen] = useState(false);
  const [selectedDetailStock, setSelectedDetailStock] = useState<StockBreakout | null>(null);
  const [selectedAiStock, setSelectedAiStock] = useState<StockBreakout | undefined>(undefined);

  const syncedSymbols = new Set(tasks.map((t) => t.symbol));

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // BroadcastChannel for instant inter-tab real-time synchronization
  useEffect(() => {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      const channel = new BroadcastChannel('breakoutpulse_tasks_channel');
      channel.onmessage = (event) => {
        if (event.data?.type === 'TASKS_SYNC' && Array.isArray(event.data.payload)) {
          setTasks(event.data.payload);
        }
      };
      return () => channel.close();
    }
  }, []);

  const broadcastTasks = (newTasks: TradingTask[]) => {
    setTasks(newTasks);
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      const channel = new BroadcastChannel('breakoutpulse_tasks_channel');
      channel.postMessage({ type: 'TASKS_SYNC', payload: newTasks });
      channel.close();
    }
  };

  const handleSyncToTasks = (stock: StockBreakout) => {
    if (syncedSymbols.has(stock.symbol)) {
      showToast(`${stock.symbol} is already synced to tasks`);
      return;
    }

    const newTask: TradingTask = {
      id: `task-${Date.now()}`,
      symbol: stock.symbol,
      priority: stock.score >= 90 ? 'CRITICAL' : 'HIGH',
      createdAt: 'Just now',
      status: 'ACTIVE',
      title: `Monitor ${stock.symbol} Breakout Trigger at ₹${stock.resistanceLevel}`,
      entryZoneMin: Number((stock.entryPrice * 0.99).toFixed(1)),
      entryZoneMax: Number((stock.entryPrice * 1.01).toFixed(1)),
      stopLoss: stock.stopLoss,
      target: stock.target1,
      notes: `${stock.confirmationRule}. Catalyst: ${stock.catalyst}`,
      checklist: [
        { id: `c-${Date.now()}-1`, text: `15-min candle close strictly above ₹${stock.resistanceLevel}`, completed: false },
        { id: `c-${Date.now()}-2`, text: `Verify RVOL >= 1.5x on breakout volume`, completed: false },
        { id: `c-${Date.now()}-3`, text: `Set hard GTT Stop Loss at ₹${stock.stopLoss}`, completed: false },
        { id: `c-${Date.now()}-4`, text: `Position sized strictly within 2% capital risk`, completed: false },
      ],
      syncedOrigin: 'Scanner Auto-Sync',
    };

    broadcastTasks([newTask, ...tasks]);
    showToast(`✓ Added ${stock.symbol} to Synced Tasks`);
  };

  const handleUpdateTaskStatus = (id: string, status: TaskStatus) => {
    const updated = tasks.map((t) => (t.id === id ? { ...t, status } : t));
    broadcastTasks(updated);
    showToast(`Status updated to ${status}`);
  };

  const handleToggleChecklist = (taskId: string, checkId: string) => {
    const updated = tasks.map((t) => {
      if (t.id !== taskId) return t;
      return {
        ...t,
        checklist: t.checklist.map((item) =>
          item.id === checkId ? { ...item, completed: !item.completed } : item
        ),
      };
    });
    broadcastTasks(updated);
  };

  const handleDeleteTask = (id: string) => {
    const updated = tasks.filter((t) => t.id !== id);
    broadcastTasks(updated);
    showToast('Task removed from workspace');
  };

  const handleSaveNewTask = (taskData: Omit<TradingTask, 'id' | 'createdAt'>) => {
    const newTask: TradingTask = {
      ...taskData,
      id: `task-${Date.now()}`,
      createdAt: 'Just now',
    };
    broadcastTasks([newTask, ...tasks]);
    showToast(`✓ Created new task for ${newTask.symbol}`);
  };

  const handlePlaceOrder = (orderData: Omit<Order, 'id' | 'placedAt'>) => {
    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      placedAt: 'Just now',
    };
    setOrders([newOrder, ...orders]);

    const newPosition: Position = {
      id: `pos-${Date.now()}`,
      symbol: orderData.symbol,
      type: orderData.type,
      quantity: orderData.quantity,
      avgPrice: orderData.price,
      currentPrice: orderData.price,
      pnl: 0,
      pnlPercent: 0,
      stopLoss: orderData.price * 0.95,
      target: orderData.price * 1.15,
      openedAt: 'Just now',
    };
    setPositions([newPosition, ...positions]);
    showToast(`✓ Executed paper order: ${orderData.quantity} QTY of ${orderData.symbol}`);
  };

  const handleClosePosition = (id: string) => {
    setPositions(positions.filter((p) => p.id !== id));
    showToast('Squared off paper position');
  };

  const handleResetAccount = () => {
    setPositions([]);
    setOrders([]);
    showToast('Virtual Demat balance reset to ₹10,00,000');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Fixed Toast notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-emerald-500 text-slate-950 font-bold px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs animate-bounce">
          <Check className="w-4 h-4 stroke-[3]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main App Container */}
      {viewMode === 'android' ? (
        // Android Phone Mockup Frame
        <div className="flex-1 flex items-center justify-center py-6 px-2 bg-slate-900/50">
          <div className="w-full max-w-[420px] bg-slate-950 border-[10px] border-slate-800 rounded-[48px] shadow-2xl overflow-hidden relative flex flex-col min-h-[860px]">
            {/* Top Phone Speaker & Camera Notch */}
            <div className="h-6 bg-slate-950 flex items-center justify-center relative z-50 shrink-0">
              <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-800" />
            </div>

            {/* Header in Android frame */}
            <HeaderBar
              {...liveProps}
              viewMode={viewMode}
              setViewMode={setViewMode}
              onlineDevices={onlineDevices}
              alertsCount={alertsCount}
              onOpenAlerts={() => setShowAlertsBanner(!showAlertsBanner)}
            />

            {/* Scrollable Content inside phone */}
            <main className="flex-1 overflow-y-auto p-4 max-h-[700px] no-scrollbar">
              {renderActiveTabContent()}
            </main>

            {/* Floating Action Button inside phone */}
            <button
              onClick={() => setIsNewTaskModalOpen(true)}
              className="absolute right-5 bottom-16 z-30 w-12 h-12 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/30 transition cursor-pointer text-xl"
              aria-label="Add New Trading Task"
            >
              <Plus className="w-6 h-6 stroke-[3]" />
            </button>

            {/* Bottom Nav inside phone */}
            <BottomNav
              activeTab={activeTab}
              setActiveTab={setActiveTab}
              tasksCount={tasks.length}
            />
          </div>
        </div>
      ) : (
        // Expanded Full Desktop View
        <div className="flex-1 flex flex-col">
          <HeaderBar
            {...liveProps}
            viewMode={viewMode}
            setViewMode={setViewMode}
            onlineDevices={onlineDevices}
            alertsCount={alertsCount}
            onOpenAlerts={() => setShowAlertsBanner(!showAlertsBanner)}
          />

          {/* Active Alerts Banner if toggled */}
          {showAlertsBanner && (
            <div className="bg-emerald-500/10 border-b border-emerald-500/20 px-4 py-2.5 text-xs">
              <div className="max-w-7xl mx-auto flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-emerald-400" />
                  <span className="font-semibold text-emerald-300">
                    7 Breakout Alerts Active: LT, DIXON, BHARTIARTL, EMS, TRENT testing resistance with high RVOL.
                  </span>
                </div>
                <button
                  onClick={() => setShowAlertsBanner(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 pb-28">
            {renderActiveTabContent()}
          </main>

          {/* Floating Action Button (FAB) */}
          <button
            onClick={() => setIsNewTaskModalOpen(true)}
            style={{ marginBottom: "env(safe-area-inset-bottom)" }} className="fixed right-4 bottom-20 z-30 w-12 h-12 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-full flex items-center justify-center shadow-xl shadow-emerald-500/30 transition cursor-pointer text-xl"
            aria-label="Add New Trading Task"
          >
            <Plus className="w-6 h-6 stroke-[3]" />
          </button>

          <BottomNav
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            tasksCount={tasks.length}
          />
        </div>
      )}

      {/* Modals */}
      <NewTaskModal
        isOpen={isNewTaskModalOpen}
        onClose={() => setIsNewTaskModalOpen(false)}
        onSaveTask={handleSaveNewTask}
      />

      <StockDetailModal
        stock={selectedDetailStock}
        onClose={() => setSelectedDetailStock(null)}
        onSyncToTasks={handleSyncToTasks}
        onOpenTrade={(stock) => {
          setActiveTab('trade');
          showToast(`Opened paper trading for ${stock.symbol}`);
        }}
        onOpenAiPrompt={(stock) => {
          setSelectedAiStock(stock);
          setActiveTab('aiprompts');
        }}
      />
    </div>
  );

  function renderActiveTabContent() {
    switch (activeTab) {
      case 'scanner':
        return (
          <ScannerTab
            stocks={MOCK_STOCKS}
            onSyncToTasks={handleSyncToTasks}
            onOpenAiPrompt={(stock) => {
              setSelectedAiStock(stock);
              setActiveTab('aiprompts');
            }}
            onOpenDetails={(stock) => setSelectedDetailStock(stock)}
            syncedSymbols={syncedSymbols}
          />
        );
      case 'backtest':
        return (
          <BacktestTab
            onDeployToPaper={() => {
              setActiveTab('trade');
              showToast('Strategy deployed to Live Paper Terminal');
            }}
          />
        );
      case 'trade':
        return (
          <TradeTerminalTab
            positions={positions}
            orders={orders}
            onPlaceOrder={handlePlaceOrder}
            onClosePosition={handleClosePosition}
            onResetAccount={handleResetAccount}
          />
        );
      case 'analytics':
        return <AnalyticsTab />;
      case 'journal':
        return <JournalTab />;
      case 'aiprompts':
        return <AiPromptsTab initialStock={selectedAiStock} />;
      case 'tasks':
        return (
          <TasksTab
            tasks={tasks}
            onUpdateStatus={handleUpdateTaskStatus}
            onToggleChecklist={handleToggleChecklist}
            onDeleteTask={handleDeleteTask}
            onOpenNewTask={() => setIsNewTaskModalOpen(true)}
            onOpenSyncHub={() => setActiveTab('synchub')}
          />
        );
      case 'indexscalp':
        return <IndexScalpTab />;
      case 'synchub':
        return (
          <SyncHubTab
            tasks={tasks}
            onImportTasks={(imported) => {
              broadcastTasks(imported);
              showToast('Tasks imported from backup JSON');
            }}
            onlineDevices={onlineDevices}
          />
        );
      default:
        return null;
    }
  }
}
