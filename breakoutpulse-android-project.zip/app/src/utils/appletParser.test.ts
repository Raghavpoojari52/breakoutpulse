import test from 'node:test';
import assert from 'node:assert/strict';
import { parseAppletUrl, generateScaffoldPrompt, ARCHETYPES } from './appletParser';

test('parseAppletUrl accurately parses AI Studio app URL', () => {
  const url = 'https://aistudio.google.com/apps/35c0861a-d004-412e-bf3d-6603a339123c?showAssistant=true&showPreview=true';
  const result = parseAppletUrl(url);

  assert.equal(result.isValid, true);
  assert.equal(result.appletId, '35c0861a-d004-412e-bf3d-6603a339123c');
  assert.equal(result.showAssistant, true);
  assert.equal(result.showPreview, true);
  assert.equal(result.domain, 'aistudio.google.com');
});

test('parseAppletUrl handles raw UUID strings', () => {
  const uuid = '35c0861a-d004-412e-bf3d-6603a339123c';
  const result = parseAppletUrl(uuid);

  assert.equal(result.isValid, true);
  assert.equal(result.appletId, uuid);
});

test('parseAppletUrl handles invalid or empty inputs gracefully', () => {
  assert.equal(parseAppletUrl('').isValid, false);
  assert.equal(parseAppletUrl('https://google.com').isValid, false);
  assert.equal(parseAppletUrl('random text').isValid, false);
});

test('generateScaffoldPrompt generates comprehensive scaffold with custom details', () => {
  const prompt = generateScaffoldPrompt('saas-dashboard', 'Add dark mode toggle and real-time updates');
  assert.ok(prompt.toLowerCase().includes('modern b2b saas dashboard'));
  assert.ok(prompt.includes('KPI summary metric cards'));
  assert.ok(prompt.includes('Add dark mode toggle and real-time updates'));
});

test('ARCHETYPES list contains expected presets', () => {
  assert.equal(ARCHETYPES.length, 4);
  assert.ok(ARCHETYPES.some((a) => a.id === 'ai-multimodal'));
  assert.ok(ARCHETYPES.some((a) => a.id === 'workflow-kanban'));
});
