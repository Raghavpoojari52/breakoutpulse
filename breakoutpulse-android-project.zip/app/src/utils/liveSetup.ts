import type { Candle, StockBreakout } from '../types/trading.ts';
import { calculateRiskReward } from './calculations.ts';

export interface QuoteLite { last: number; netChange: number; volume: number }

const avg = (a: number[]) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
const r2 = (n: number) => Number(n.toFixed(2));

/** Add 20/50 DMA to ascending candles. */
export function withDmas(raw: Omit<Candle, 'dma20' | 'dma50'>[]): Candle[] {
  return raw.map((c, i) => ({
    ...c,
    dma20: r2(avg(raw.slice(Math.max(0, i - 19), i + 1).map((x) => x.close))),
    dma50: r2(avg(raw.slice(Math.max(0, i - 49), i + 1).map((x) => x.close))),
  }));
}

/**
 * Rule-based breakout read from real daily candles (ascending) + live quote.
 * Needs >= 30 candles. Returns fields to merge into a StockBreakout, or null.
 */
export function buildSetup(candlesAsc: Candle[], q: QuoteLite): Partial<StockBreakout> | null {
  if (candlesAsc.length < 30 || !(q.last > 0)) return null;
  const hist = candlesAsc;                       // completed sessions
  const last20 = hist.slice(-20);
  const resistance = Math.max(...last20.map((c) => c.high));
  const support = Math.min(...hist.slice(-10).map((c) => c.low));
  const avgVol = avg(last20.map((c) => c.volume));
  const rvol = avgVol > 0 ? q.volume / avgVol : 0;
  const prev = q.last - q.netChange;
  const changePercent = prev > 0 ? (q.netChange / prev) * 100 : 0;

  const dma20 = hist[hist.length - 1].dma20;
  const dma50 = hist[hist.length - 1].dma50;
  const range = (c: Candle) => (c.high - c.low) / (c.close || 1);
  const tight = avg(hist.slice(-5).map(range)) / (avg(last20.map(range)) || 1);
  const distPct = ((resistance - q.last) / resistance) * 100; // >0 below resistance

  let score = 0;
  if (q.last > dma20 && dma20 > dma50) score += 35; else if (q.last > dma50) score += 15;
  if (distPct <= 3 && distPct >= -3) score += 25; else if (distPct <= 6 && distPct > 3) score += 10;
  score += rvol >= 2 ? 25 : rvol >= 1.5 ? 18 : rvol >= 1 ? 8 : 0;
  if (tight < 0.8) score += 15;
  score = Math.min(100, score);

  const entry = r2(resistance * 1.005);
  const sl = r2(support * 0.999);
  const risk = Math.max(entry - sl, entry * 0.005);
  const target1 = r2(entry + 2 * risk);
  const target2 = r2(entry + 3 * risk);

  let setupStatus: StockBreakout['setupStatus'] = 'NO SUITABLE SETUP';
  if (q.last > resistance && rvol >= 1.5) setupStatus = 'TRIGGERED';
  else if (score >= 70 && distPct <= 3) setupStatus = 'SETUP READY';
  else if (score >= 45) setupStatus = 'WATCHLIST';

  return {
    currentPrice: r2(q.last),
    changePercent: r2(changePercent),
    rvol: r2(rvol),
    score,
    buyAlertPercent: score,
    setupStatus,
    resistanceLevel: r2(resistance),
    supportLevel: r2(support),
    entryPrice: entry,
    stopLoss: sl,
    target1,
    target2,
    riskReward: calculateRiskReward(entry, sl, target1).label,
    confirmationRule: `Daily close above ₹${r2(resistance)} with RVOL ≥ 1.5x.`,
    invalidationRule: `Daily close below ₹${sl}.`,
    catalyst: 'Derived from real NSE daily price & volume via your Upstox account.',
    candles: hist.slice(-40),
  };
}
