import { buildSetup, withDmas } from './liveSetup.ts';
// synthetic uptrend then consolidation under a 110 high
const raw = Array.from({ length: 60 }, (_, i) => {
  const base = 80 + i * 0.5;
  return { date: `d${i}`, open: base, close: base + 0.2, high: Math.min(base + 1, 109.5), low: base - 1, volume: 1_000_000 };
});
const s = buildSetup(withDmas(raw), { last: 108.7, netChange: 1.1, volume: 1_700_000 })!;
console.log(JSON.stringify({ st: s.setupStatus, score: s.score, rvol: s.rvol, res: s.resistanceLevel, rr: s.riskReward, chg: s.changePercent, n: s.candles!.length }));
const assert = (c: boolean, m: string) => { if (!c) { console.error('FAIL', m); process.exit(1); } };
assert(s.rvol === 1.7, 'rvol'); assert(s.resistanceLevel! >= 109 && s.resistanceLevel! <= 110, 'res');
assert(s.entryPrice! > s.resistanceLevel!, 'entry>res'); assert(s.stopLoss! < s.entryPrice!, 'sl<entry');
assert(s.score! >= 45, 'score'); assert(buildSetup(withDmas(raw.slice(0, 10)), { last: 1, netChange: 0, volume: 1 }) === null, 'short history');
console.log('OK');
