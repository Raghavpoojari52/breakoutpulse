export function calculateRiskReward(entry: number, stopLoss: number, target: number): { ratio: number; label: string } {
  const risk = Math.abs(entry - stopLoss);
  const reward = Math.abs(target - entry);

  if (risk === 0) {
    return { ratio: 0, label: '1:0' };
  }

  const ratio = Number((reward / risk).toFixed(2));
  return {
    ratio,
    label: `1:${Math.round(ratio * 10) / 10}`,
  };
}

export function calculatePositionSize(
  totalCapital: number,
  riskPercent: number,
  entryPrice: number,
  stopLossPrice: number
): { quantity: number; totalExposure: number; totalRiskAmount: number } {
  const riskPerShare = Math.abs(entryPrice - stopLossPrice);
  const maxRiskAmount = (totalCapital * riskPercent) / 100;

  if (riskPerShare <= 0 || maxRiskAmount <= 0 || entryPrice <= 0) {
    return { quantity: 0, totalExposure: 0, totalRiskAmount: 0 };
  }

  const rawQty = Math.floor(maxRiskAmount / riskPerShare);
  // Cap exposure to total capital
  const maxAffordableQty = Math.floor(totalCapital / entryPrice);
  const quantity = Math.max(0, Math.min(rawQty, maxAffordableQty));

  return {
    quantity,
    totalExposure: Number((quantity * entryPrice).toFixed(2)),
    totalRiskAmount: Number((quantity * riskPerShare).toFixed(2)),
  };
}

export function calculatePnL(quantity: number, buyPrice: number, currentPrice: number): { pnl: number; pnlPercent: number } {
  if (quantity <= 0 || buyPrice <= 0) {
    return { pnl: 0, pnlPercent: 0 };
  }
  const pnl = Number(((currentPrice - buyPrice) * quantity).toFixed(2));
  const pnlPercent = Number((((currentPrice - buyPrice) / buyPrice) * 100).toFixed(2));
  return { pnl, pnlPercent };
}

export function formatINR(val: number): string {
  if (isNaN(val)) return '₹0';
  const isNeg = val < 0;
  const abs = Math.abs(val);

  // Indian Number Format (lakhs & crores)
  const parts = abs.toFixed(2).split('.');
  let lastThree = parts[0].substring(parts[0].length - 3);
  const otherNumbers = parts[0].substring(0, parts[0].length - 3);
  if (otherNumbers !== '') {
    lastThree = ',' + lastThree;
  }
  const formatted = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;
  const result = parts[1] === '00' ? formatted : `${formatted}.${parts[1]}`;

  return `${isNeg ? '-' : ''}₹${result}`;
}

export function getRvolBadge(rvol: number): { label: string; color: string } {
  if (rvol >= 2.0) {
    return { label: `RVOL ${rvol.toFixed(2)}x`, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' };
  }
  if (rvol >= 1.5) {
    return { label: `RVOL ${rvol.toFixed(2)}x`, color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20' };
  }
  if (rvol >= 1.0) {
    return { label: `RVOL ${rvol.toFixed(2)}x`, color: 'text-slate-300 bg-slate-800 border-slate-700' };
  }
  return { label: `RVOL ${rvol.toFixed(2)}x`, color: 'text-slate-400 bg-slate-900 border-slate-800' };
}
