import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateRiskReward, calculatePositionSize, calculatePnL, formatINR, getRvolBadge } from './calculations';

test('calculateRiskReward calculates exact 1:2 and 1:3 ratios', () => {
  const rr1 = calculateRiskReward(100, 90, 120);
  assert.equal(rr1.ratio, 2);
  assert.equal(rr1.label, '1:2');

  const rr2 = calculateRiskReward(100, 95, 115);
  assert.equal(rr2.ratio, 3);
  assert.equal(rr2.label, '1:3');
});

test('calculatePositionSize protects account capital within risk percentage', () => {
  // ₹10,00,000 capital, 1% risk = ₹10,000 max loss
  // Entry: ₹1,000, Stop Loss: ₹950 (Risk per share = ₹50)
  // Max shares = 10,000 / 50 = 200 shares
  const result = calculatePositionSize(1000000, 1, 1000, 950);
  assert.equal(result.quantity, 200);
  assert.equal(result.totalRiskAmount, 10000);
  assert.equal(result.totalExposure, 200000);
});

test('calculatePnL computes positive and negative returns accurately', () => {
  const win = calculatePnL(100, 50, 60);
  assert.equal(win.pnl, 1000);
  assert.equal(win.pnlPercent, 20);

  const loss = calculatePnL(100, 50, 45);
  assert.equal(loss.pnl, -500);
  assert.equal(loss.pnlPercent, -10);
});

test('formatINR formats lakhs and thousands accurately', () => {
  assert.equal(formatINR(1000000), '₹10,00,000');
  assert.equal(formatINR(3740), '₹3,740');
  assert.equal(formatINR(-57689), '-₹57,689');
});

test('getRvolBadge assigns proper highlighting', () => {
  assert.ok(getRvolBadge(2.39).color.includes('emerald'));
  assert.ok(getRvolBadge(1.73).color.includes('cyan'));
});
