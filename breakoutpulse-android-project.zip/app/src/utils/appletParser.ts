export interface ParsedAppletUrl {
  isValid: boolean;
  appletId?: string;
  showAssistant?: boolean;
  showPreview?: boolean;
  domain?: string;
  rawUrl: string;
}

export interface ProjectArchetype {
  id: string;
  name: string;
  badge: string;
  description: string;
  icon: string;
  samplePrompt: string;
  defaultFeatures: string[];
}

export function parseAppletUrl(urlString: string): ParsedAppletUrl {
  if (!urlString || typeof urlString !== 'string') {
    return { isValid: false, rawUrl: '' };
  }

  const trimmed = urlString.trim();
  try {
    const url = new URL(trimmed);
    const domain = url.hostname;

    // Check if it's an AI Studio URL
    const isAiStudio = domain.includes('aistudio.google.com') || domain.includes('ais-');
    
    // Extract applet ID from pathname: /apps/:id or query or direct match
    const match = url.pathname.match(/\/apps\/([a-zA-Z0-9_-]+)/);
    const appletId = match ? match[1] : undefined;

    return {
      isValid: Boolean(isAiStudio && appletId),
      appletId,
      showAssistant: url.searchParams.get('showAssistant') === 'true',
      showPreview: url.searchParams.get('showPreview') === 'true',
      domain,
      rawUrl: trimmed,
    };
  } catch {
    // If not a valid URL, check if it's a raw UUID
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (uuidRegex.test(trimmed)) {
      return {
        isValid: true,
        appletId: trimmed,
        rawUrl: trimmed,
      };
    }
    return { isValid: false, rawUrl: trimmed };
  }
}

export const ARCHETYPES: ProjectArchetype[] = [
  {
    id: 'ai-multimodal',
    name: 'Gemini Multimodal Studio',
    badge: 'AI & Generation',
    description: 'Interactive multimodal workspace supporting text prompts, image analysis, code generation, and preset templates.',
    icon: 'Sparkles',
    samplePrompt: 'Build an AI Creative Studio with multimodal image inspection, prompt recipes, history drawer, and exportable outputs.',
    defaultFeatures: ['Multimodal prompt input', 'Gemini 2.5 Flash execution', 'History log with tags', 'Export to Markdown/JSON'],
  },
  {
    id: 'saas-dashboard',
    name: 'Modern SaaS Analytics',
    badge: 'Enterprise & Data',
    description: 'High-density operational dashboard with real-time KPI metrics, interactive data tables, date filters, and performance graphs.',
    icon: 'BarChart3',
    samplePrompt: 'Create a modern B2B SaaS dashboard with revenue charts, user conversion funnel, activity feed, and team member management.',
    defaultFeatures: ['KPI summary metric cards', 'Interactive chart visualizer', 'Paginated filterable table', 'Status indicators'],
  },
  {
    id: 'workflow-kanban',
    name: 'Agile Task & Project Board',
    badge: 'Productivity',
    description: 'Fluid drag-and-drop kanban board with column customization, task priorities, search filtering, and activity timeline.',
    icon: 'Kanban',
    samplePrompt: 'Design a project management board with draggable stages (Backlog, In Progress, Review, Done), task details modal, and tag filters.',
    defaultFeatures: ['Interactive columns', 'Task search and label filters', 'Priority indicators', 'Quick task creation drawer'],
  },
  {
    id: 'developer-sandbox',
    name: 'Dev Tool & API Tester',
    badge: 'Developer Tools',
    description: 'Technical playground for crafting payloads, inspecting headers, JSON formatting, curl generation, and latency monitoring.',
    icon: 'Terminal',
    samplePrompt: 'Build an API client and JSON inspector with syntax highlighting, cURL importer, response timing, and request collections.',
    defaultFeatures: ['HTTP request composer', 'JSON viewer & formatter', 'cURL export generator', 'Saved requests drawer'],
  },
];

export function generateScaffoldPrompt(archetypeId: string, customDetails: string = ''): string {
  const archetype = ARCHETYPES.find((a) => a.id === archetypeId);
  if (!archetype) return customDetails;

  return `${archetype.samplePrompt}\n\nKey Core Requirements:\n${archetype.defaultFeatures.map((f) => `- ${f}`).join('\n')}${
    customDetails ? `\n\nAdditional User Specifications:\n${customDetails}` : ''
  }`;
}
