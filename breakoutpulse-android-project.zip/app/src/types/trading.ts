export type MarketCap = 'ALL' | 'LARGE' | 'MID' | 'SMALL';

export type StrategyType =
  | 'all'
  | 'complete-breakout'
  | 'volume-breakout'
  | 'retest'
  | 'early-squeeze'
  | 'vcp'
  | 'mtf-30-40';

export interface Candle {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  dma20: number;
  dma50: number;
}

export interface StockBreakout {
  symbol: string;
  name: string;
  sector: string;
  marketCap: 'LARGE' | 'MID' | 'SMALL';
  currentPrice: number;
  changePercent: number;
  rvol: number;
  deliveryPercent: number;
  setupStatus: 'SETUP READY' | 'WATCHLIST' | 'TRIGGERED' | 'NO SUITABLE SETUP';
  buyAlertPercent: number;
  score: number;
  resistanceLevel: number;
  supportLevel: number;
  entryPrice: number;
  stopLoss: number;
  target1: number;
  target2: number;
  riskReward: string;
  strategy: StrategyType;
  confirmationRule: string;
  invalidationRule: string;
  catalyst: string;
  candles: Candle[];
}

export type TaskStatus = 'ACTIVE' | 'PENDING' | 'TRIGGERED' | 'EXECUTED' | 'TARGET HIT' | 'INVALIDATED';

export interface TaskChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface TradingTask {
  id: string;
  symbol: string;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  createdAt: string;
  status: TaskStatus;
  title: string;
  entryZoneMin: number;
  entryZoneMax: number;
  stopLoss: number;
  target: number;
  notes: string;
  checklist: TaskChecklistItem[];
  syncedOrigin: string;
}

export interface Position {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  stopLoss: number;
  target: number;
  openedAt: string;
}

export interface Order {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  orderType: 'MARKET' | 'LIMIT' | 'GTT_BREAKOUT';
  quantity: number;
  price: number;
  triggerPrice?: number;
  status: 'EXECUTED' | 'PENDING' | 'CANCELLED';
  placedAt: string;
}

export interface JournalEntry {
  id: string;
  date: string;
  symbol: string;
  outcome: 'WIN' | 'LOSS' | 'BREAKEVEN';
  pnl: number;
  setupType: string;
  disciplineScore: number; // 1-10
  notes: string;
  rulesFollowed: boolean;
  tags: string[];
}
